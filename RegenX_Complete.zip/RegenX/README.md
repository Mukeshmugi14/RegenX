# ♻ RegenX — Circular Economy Platform
### React Native + Firebase · Complete Mobile App

---

## 📁 Project Structure

```
RegenX/
├── App.js                          # Root entry point
├── app.json                        # Expo config + permissions
├── babel.config.js                 # Babel + path aliases
├── package.json                    # All dependencies
├── firebase.json                   # Firebase project config
├── firestore.rules                 # Firestore security rules
├── firestore.indexes.json          # Composite index definitions
├── storage.rules                   # Firebase Storage rules
│
└── src/
    ├── firebase/
    │   ├── config.js               # Firebase init + exports
    │   ├── auth.js                 # Auth service (register/login/logout)
    │   ├── firestore.js            # All Firestore CRUD operations
    │   └── storage.js              # Image upload/delete
    │
    ├── store/
    │   ├── index.js                # Redux store config
    │   ├── userSlice.js            # User profile + score state
    │   ├── listingsSlice.js        # Listings + draft state
    │   └── uiSlice.js              # Toast notifications + UI state
    │
    ├── hooks/
    │   ├── useAuth.js              # Auth state + real-time profile sync
    │   └── useListings.js          # Real-time listings subscription
    │
    ├── navigation/
    │   ├── AppNavigator.js         # Root navigator (Auth vs Main)
    │   ├── AuthNavigator.js        # Login / Register stack
    │   └── MainNavigator.js        # Tab navigator + stacks + custom tab bar
    │
    ├── screens/
    │   ├── LoginScreen.js          # Email/password login
    │   ├── RegisterScreen.js       # Role-based registration
    │   ├── HomeScreen.js           # Regen Score dashboard + impact metrics
    │   ├── CameraScreen.js         # 60s live-only camera + AI scan + barcode
    │   ├── ListingScreen.js        # 4-question listing form + urgency routing
    │   ├── NoBuyerScreen.js        # 3-action recovery screen + mini-map
    │   ├── MyListingsScreen.js     # Listings history with filter tabs
    │   └── ProfileScreen.js        # User profile + tier journey + settings
    │
    └── utils/
        ├── theme.js                # Colors, typography, spacing, shadows
        ├── constants.js            # Enums, categories, tiers, points
        └── helpers.js              # Score helpers, validators, formatters
```

---

## 🛠 Tech Stack

| Layer          | Technology                        |
|----------------|-----------------------------------|
| Framework      | React Native + Expo SDK 50        |
| Navigation     | React Navigation 6 (Stack + Tabs) |
| State          | Redux Toolkit + React-Redux       |
| Backend        | Firebase v10 (Auth + Firestore + Storage) |
| Camera         | expo-camera + expo-barcode-scanner |
| Maps           | react-native-maps (Google Maps)   |
| Location       | expo-location                     |
| Animations     | React Native Animated API         |
| Gradients      | expo-linear-gradient              |
| Vector Icons   | react-native-vector-icons         |

---

## 🚀 Setup Instructions

### 1. Clone & Install

```bash
git clone <repo>
cd RegenX
npm install
```

### 2. Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create a new project: `regenx-app`
3. Enable **Authentication** → Email/Password
4. Enable **Firestore Database** (Start in production mode)
5. Enable **Firebase Storage**
6. Add a **Web App** in Project Settings

### 3. Configure Firebase

Edit `src/firebase/config.js` and replace the placeholder values:

```js
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "regenx-app.firebaseapp.com",
  projectId: "regenx-app",
  storageBucket: "regenx-app.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
};
```

### 4. Deploy Firestore Rules & Indexes

```bash
npm install -g firebase-tools
firebase login
firebase init   # Select Firestore, Storage, use existing project
firebase deploy --only firestore:rules,firestore:indexes,storage
```

### 5. Seed Initial Data (NGOs + Recycling Centres)

Create these Firestore collections manually or via the Admin SDK:

**`ngos` collection:**
```json
{
  "name": "Sadahar Food Bank",
  "verified": true,
  "acceptingDonations": true,
  "accepts": ["food", "medicine"],
  "freePickup": true,
  "location": { "lat": 12.9716, "lng": 80.2209 }
}
```

**`recyclingCentres` collection:**
```json
{
  "name": "GreenHub Recycling",
  "lat": 12.9720,
  "lng": 80.2210,
  "types": ["plastic", "metal", "ewaste"],
  "open": true,
  "hours": "9am–6pm Mon–Sat"
}
```

### 6. Run the App

```bash
# Start Expo Dev Server
npx expo start

# Run on Android emulator
npx expo run:android

# Run on iOS simulator
npx expo run:ios
```

---

## 🔐 Key Features & Logic

### Regen Score System
- **0–249**: Seedling 🌱
- **250–499**: Grower 🌿
- **500–749**: Pioneer 🌳
- **750–999**: Guardian 🛡
- **1000**: Champion 🏆

### Points Distribution
| Action                    | Points |
|---------------------------|--------|
| New listing created       | +15    |
| Food/medicine (urgent ≤2d)| +35    |
| Food (normal)             | +23    |
| Free listing bonus        | +10    |
| Relist at lower price     | +12    |
| Donate to NGO             | +28    |
| Navigate to recycling     | +20    |

### Camera Trust Enforcement
- Gallery uploads are **disabled at UI + storage rule level**
- `source: 'live_camera'` metadata required by Storage Rules
- 60-second listing window enforced client-side

### Urgency Auto-Routing
- Food/medicine expiring in ≤2 days triggers bold URGENT banner
- Auto-routes to nearest verified NGO with free pickup
- Bonus points awarded for urgent listings

### No-Buyer Net
- Triggers after 7 days without a sale (`noBuyerAt` timestamp)
- Three distinct recovery paths:
  1. **Relist** at suggested 30% discount
  2. **Donate** to verified NGO (free pickup)
  3. **Recycle** via nearest certified centre (with navigation)

---

## 📱 Screen Flow

```
Splash → Login/Register → Home Dashboard
                              ↓
                      [FAB] Scan to List
                              ↓
                       Camera (60s window)
                              ↓
                       Listing Modal (4 questions)
                              ↓
                    Published → Activity Feed
                              ↓ (after 7 days)
                       No-Buyer Net Screen
                    ↙          ↓           ↘
                Relist      Donate      Recycle
```

---

## 🔧 Environment Variables (Optional)

Create `.env` at root for additional configs:

```env
EXPO_PUBLIC_GOOGLE_MAPS_API_KEY=your_maps_api_key
EXPO_PUBLIC_AI_API_URL=your_ai_service_url
```

Update `app.json` under `extra` for Google Maps:
```json
"android": {
  "config": {
    "googleMaps": {
      "apiKey": "YOUR_GOOGLE_MAPS_API_KEY"
    }
  }
}
```
