// src/utils/constants.js

export const USER_ROLES = {
  FARMER: 'farmer',
  CONSUMER: 'consumer',
  SHG: 'shg',
  TRANSPORTER: 'transporter',
};

export const ITEM_CATEGORIES = [
  { id: 'crop_residue', label: 'Crop Residue', icon: '🌾', role: 'farmer' },
  { id: 'food', label: 'Near-Expiry Food', icon: '🥗', role: 'all' },
  { id: 'ecommerce', label: 'Returned Goods', icon: '📦', role: 'consumer' },
  { id: 'ewaste', label: 'E-Waste', icon: '🔌', role: 'all' },
  { id: 'medicine', label: 'Near-Expiry Meds', icon: '💊', role: 'all' },
  { id: 'textile', label: 'Clothing/Textile', icon: '👕', role: 'all' },
  { id: 'furniture', label: 'Furniture', icon: '🪑', role: 'all' },
  { id: 'tools', label: 'Tools/Equipment', icon: '🔧', role: 'all' },
];

export const CONDITIONS = ['Like New', 'Good', 'Fair', 'Poor'];

export const LISTING_STATUS = {
  ACTIVE: 'active',
  SOLD: 'sold',
  DONATED: 'donated',
  RECYCLED: 'recycled',
  EXPIRED: 'expired',
  NO_BUYER: 'no_buyer',
};

export const TIERS = [
  { name: 'Seedling', min: 0, max: 249, icon: '🌱' },
  { name: 'Grower', min: 250, max: 499, icon: '🌿' },
  { name: 'Pioneer', min: 500, max: 749, icon: '🌳' },
  { name: 'Guardian', min: 750, max: 999, icon: '🛡' },
  { name: 'Champion', min: 1000, max: 1000, icon: '🏆' },
];

export const POINTS = {
  LISTING_CREATED: 15,
  FOOD_URGENT: 20,     // expires in ≤2 days
  FOOD_NORMAL: 8,
  FREE_LISTING: 10,
  RELIST: 12,
  DONATION: 28,
  RECYCLING: 20,
  SALE: 18,
};

export const CAMERA_TIMEOUT_MS = 60 * 1000; // 60 seconds

export const NGO_TRIGGERS = {
  FOOD_EXPIRY_DAYS: 2,   // Auto-route if expires within 2 days
  MEDICINE_EXPIRY_DAYS: 3,
};

export const FIRESTORE_COLLECTIONS = {
  USERS: 'users',
  LISTINGS: 'listings',
  NGOS: 'ngos',
  RECYCLING: 'recyclingCentres',
  DONATIONS: 'donations',
  ACTIVITY: 'activity',
  TRANSPORTERS: 'transporters',
};

export const QUICK_CATEGORIES = [
  { id: 'crop_residue', label: 'Crop Residue', icon: '🌾', color: '#F5C842' },
  { id: 'ecommerce', label: 'Return Goods', icon: '📦', color: '#5ABAFF' },
  { id: 'food', label: 'Near-Expiry Food', icon: '🥗', color: '#FF5C35' },
  { id: 'ewaste', label: 'E-Waste', icon: '🔌', color: '#B97FFF' },
];
