// src/utils/helpers.js
import { TIERS, POINTS, NGO_TRIGGERS } from './constants';

// ─── Tier from score ─────────────────────────────────────────────
export const getTierFromScore = (score) => {
  return [...TIERS].reverse().find((t) => score >= t.min) || TIERS[0];
};

export const getNextTier = (score) => {
  return TIERS.find((t) => score < t.min) || null;
};

export const getTierProgress = (score) => {
  const current = getTierFromScore(score);
  const next = getNextTier(score);
  if (!next) return 1;
  const range = next.min - current.min;
  const progress = score - current.min;
  return Math.min(progress / range, 1);
};

// ─── Points estimation ────────────────────────────────────────────
export const estimatePoints = ({ category, expiryDays, price, condition }) => {
  let pts = POINTS.LISTING_CREATED;
  if ((category === 'food' || category === 'medicine') && expiryDays <= NGO_TRIGGERS.FOOD_EXPIRY_DAYS) {
    pts += POINTS.FOOD_URGENT;
  } else if (category === 'food') {
    pts += POINTS.FOOD_NORMAL;
  }
  if (condition === 'Like New') pts += 5;
  if (parseInt(price) === 0) pts += POINTS.FREE_LISTING;
  return pts;
};

// ─── CO₂ from points ─────────────────────────────────────────────
export const co2FromPoints = (pts) => (pts * 0.004).toFixed(2);

// ─── Format date ─────────────────────────────────────────────────
export const formatDate = (timestamp) => {
  if (!timestamp) return '';
  const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  const now = new Date();
  const diff = now - date;
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  if (hours < 1) return 'Just now';
  if (hours < 24) return `${hours}h ago`;
  if (days === 1) return 'Yesterday';
  if (days < 7) return `${days}d ago`;
  return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
};

// ─── Urgency check ────────────────────────────────────────────────
export const isUrgentExpiry = (expiryDays, category) => {
  if (!expiryDays) return false;
  if (category === 'food' || category === 'medicine') {
    return parseInt(expiryDays) <= NGO_TRIGGERS.FOOD_EXPIRY_DAYS;
  }
  return false;
};

// ─── Format currency ─────────────────────────────────────────────
export const formatPrice = (amount) => {
  if (!amount || parseInt(amount) === 0) return 'Free';
  return `₹${parseInt(amount).toLocaleString('en-IN')}`;
};

// ─── Validate listing form ────────────────────────────────────────
export const validateListingForm = (form) => {
  const errors = {};
  if (!form.condition) errors.condition = 'Please select condition';
  if (!form.year) errors.year = 'Please select purchase year';
  if (form.price === '' || form.price === null) errors.price = 'Please enter a price';
  if ((form.category === 'food' || form.category === 'medicine') && !form.expiryDays) {
    errors.expiryDays = 'Please select expiry';
  }
  return { valid: Object.keys(errors).length === 0, errors };
};

// ─── Distance formatting ──────────────────────────────────────────
export const formatDistance = (meters) => {
  if (meters < 1000) return `${Math.round(meters)}m`;
  return `${(meters / 1000).toFixed(1)} km`;
};
