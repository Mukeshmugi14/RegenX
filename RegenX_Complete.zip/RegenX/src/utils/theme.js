// src/utils/theme.js
import { Platform } from 'react-native';

export const colors = {
  // Backgrounds
  bg: '#0D1A0F',
  bgDeep: '#060D07',
  surface: '#132016',
  card: '#1A2D1E',
  cardAlt: '#1F3524',
  border: '#2A4530',

  // Accent
  accent: '#7FEA5A',
  accentDark: '#4CAF32',
  accentDim: 'rgba(76,175,50,0.2)',

  // Semantic
  urgent: '#FF5C35',
  urgentBg: 'rgba(255,92,53,0.12)',
  gold: '#F5C842',
  goldBg: 'rgba(245,200,66,0.1)',
  blue: '#5ABAFF',
  blueBg: 'rgba(90,186,255,0.1)',
  purple: '#B97FFF',
  purpleBg: 'rgba(185,127,255,0.1)',

  // Text
  text: '#E8F5E0',
  textDim: '#9ABF9E',
  muted: '#6B8F72',

  // Status bar
  statusBar: 'light-content',
};

export const typography = {
  display: Platform.select({ ios: 'Georgia', android: 'serif' }),
  heading: Platform.select({ ios: 'System', android: 'sans-serif-condensed' }),
  body: Platform.select({ ios: 'System', android: 'sans-serif' }),
  mono: Platform.select({ ios: 'Courier New', android: 'monospace' }),

  // Font sizes
  xs: 10,
  sm: 12,
  base: 14,
  md: 16,
  lg: 18,
  xl: 22,
  xxl: 28,
  xxxl: 36,
  jumbo: 52,
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
  xxxl: 48,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  full: 9999,
};

export const shadows = {
  accent: {
    shadowColor: colors.accent,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 16,
    elevation: 10,
  },
  urgent: {
    shadowColor: colors.urgent,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
};

export const gradients = {
  accent: [colors.accentDark, colors.accent],
  urgent: ['#FF5C35', '#FF3D00'],
  gold: ['#F5C842', '#E6A800'],
  blue: ['#5ABAFF', '#2196F3'],
  card: [colors.card, colors.bg],
  bg: [colors.bgDeep, colors.bg],
};
