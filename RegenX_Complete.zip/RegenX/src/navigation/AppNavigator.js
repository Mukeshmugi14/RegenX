// src/navigation/AppNavigator.js
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useSelector } from 'react-redux';
import { selectFirebaseUser } from '../store/userSlice';
import AuthNavigator from './AuthNavigator';
import MainNavigator from './MainNavigator';
import { colors } from '../utils/theme';

const Stack = createNativeStackNavigator();

const linking = {
  prefixes: ['regenx://'],
  config: {
    screens: {
      Auth: 'auth',
      Main: {
        screens: {
          Home: 'home',
          Camera: 'scan',
          NoBuyer: 'no-buyer/:listingId',
        },
      },
    },
  },
};

export default function AppNavigator() {
  const firebaseUser = useSelector(selectFirebaseUser);

  return (
    <NavigationContainer
      linking={linking}
      theme={{
        dark: true,
        colors: {
          primary: colors.accent,
          background: colors.bg,
          card: colors.surface,
          text: colors.text,
          border: colors.border,
          notification: colors.urgent,
        },
      }}
    >
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {firebaseUser ? (
          <Stack.Screen name="Main" component={MainNavigator} />
        ) : (
          <Stack.Screen name="Auth" component={AuthNavigator} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
