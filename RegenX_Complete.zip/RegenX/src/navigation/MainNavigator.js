// src/navigation/MainNavigator.js
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from '../screens/HomeScreen';
import CameraScreen from '../screens/CameraScreen';
import ListingScreen from '../screens/ListingScreen';
import NoBuyerScreen from '../screens/NoBuyerScreen';
import ProfileScreen from '../screens/ProfileScreen';
import MyListingsScreen from '../screens/MyListingsScreen';

import { colors, spacing, radius } from '../utils/theme';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

// ─── Home Stack ────────────────────────────────────────────────────
function HomeStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="HomeMain" component={HomeScreen} />
      <Stack.Screen name="MyListings" component={MyListingsScreen} />
      <Stack.Screen name="NoBuyer" component={NoBuyerScreen} options={{ animation: 'slide_from_bottom' }} />
    </Stack.Navigator>
  );
}

// ─── Scan Stack ────────────────────────────────────────────────────
function ScanStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Camera" component={CameraScreen} />
      <Stack.Screen name="Listing" component={ListingScreen} options={{ animation: 'slide_from_bottom' }} />
    </Stack.Navigator>
  );
}

// ─── Custom Tab Bar ────────────────────────────────────────────────
function CustomTabBar({ state, descriptors, navigation }) {
  const tabs = [
    { name: 'HomeTabs', icon: '🏠', label: 'Home' },
    { name: 'ScanTabs', icon: '📷', label: 'Scan' },
    { name: 'ProfileTabs', icon: '👤', label: 'Profile' },
  ];

  return (
    <View style={styles.tabBar}>
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key];
        const isFocused = state.index === index;
        const tab = tabs[index];

        const onPress = () => {
          const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name);
          }
        };

        // Central Scan FAB
        if (route.name === 'ScanTabs') {
          return (
            <TouchableOpacity key={route.key} onPress={onPress} style={styles.fabContainer} activeOpacity={0.85}>
              <View style={[styles.fab, isFocused && styles.fabActive]}>
                <Text style={styles.fabIcon}>📷</Text>
              </View>
              <Text style={[styles.tabLabel, { color: isFocused ? colors.accent : colors.muted }]}>
                Scan
              </Text>
            </TouchableOpacity>
          );
        }

        return (
          <TouchableOpacity key={route.key} onPress={onPress} style={styles.tabItem} activeOpacity={0.7}>
            <Text style={[styles.tabIcon, { opacity: isFocused ? 1 : 0.5 }]}>{tab.icon}</Text>
            <Text style={[styles.tabLabel, { color: isFocused ? colors.accent : colors.muted }]}>
              {tab.label}
            </Text>
            {isFocused && <View style={styles.tabIndicator} />}
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

export default function MainNavigator() {
  return (
    <Tab.Navigator
      tabBar={(props) => <CustomTabBar {...props} />}
      screenOptions={{ headerShown: false }}
    >
      <Tab.Screen name="HomeTabs" component={HomeStack} />
      <Tab.Screen name="ScanTabs" component={ScanStack} />
      <Tab.Screen name="ProfileTabs" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    flexDirection: 'row',
    backgroundColor: 'rgba(13,26,15,0.97)',
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingBottom: 28,
    paddingTop: 10,
    paddingHorizontal: spacing.base,
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
    position: 'relative',
    paddingTop: 4,
  },
  tabIcon: { fontSize: 22 },
  tabLabel: { fontSize: 10, fontWeight: '600', letterSpacing: 0.5 },
  tabIndicator: {
    position: 'absolute',
    bottom: -10,
    width: 20,
    height: 2,
    backgroundColor: colors.accent,
    borderRadius: 1,
  },
  fabContainer: {
    flex: 1,
    alignItems: 'center',
    marginTop: -24,
    gap: 4,
  },
  fab: {
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: colors.accentDark,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: colors.bg,
    shadowColor: colors.accent,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 10,
  },
  fabActive: {
    backgroundColor: colors.accent,
    shadowOpacity: 0.7,
  },
  fabIcon: { fontSize: 24 },
});
