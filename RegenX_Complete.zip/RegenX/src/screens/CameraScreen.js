// src/screens/CameraScreen.js
import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  Animated, Dimensions, Alert, Vibration,
} from 'react-native';
import { Camera, CameraType, FlashMode } from 'expo-camera';
import { BarCodeScanner } from 'expo-barcode-scanner';
import { LinearGradient } from 'expo-linear-gradient';
import { useDispatch } from 'react-redux';
import { updateDraft } from '../store/listingsSlice';
import { uploadListingImage } from '../firebase/storage';
import { useAuth } from '../hooks/useAuth';
import { colors, spacing, radius } from '../utils/theme';
import { CAMERA_TIMEOUT_MS } from '../utils/constants';

const { width, height } = Dimensions.get('window');
const TIMEOUT_SECS = 60;

// ── Simulated AI Detection (replace with real ML model / API) ─────
const simulateAIDetection = (category) => {
  const detections = {
    crop_residue: { name: 'Wheat Straw Bundle', category: 'Crop Residue', confidence: 91 },
    food: { name: 'Surplus Wheat Flour 5kg', category: 'Food', confidence: 94 },
    ecommerce: { name: 'Returned Electronics Package', category: 'E-Commerce Return', confidence: 87 },
    ewaste: { name: 'Old Laptop Battery', category: 'E-Waste', confidence: 89 },
  };
  return detections[category] || { name: 'Unlabeled Item', category: 'General', confidence: 72 };
};

export default function CameraScreen({ navigation, route }) {
  const dispatch = useDispatch();
  const { uid } = useAuth();
  const cameraRef = useRef(null);

  const [hasPermission, setHasPermission] = useState(null);
  const [mode, setMode] = useState('scan'); // 'scan' | 'barcode'
  const [scanning, setScanning] = useState(false);
  const [detected, setDetected] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [timeLeft, setTimeLeft] = useState(TIMEOUT_SECS);
  const [timerActive, setTimerActive] = useState(false);
  const [flash, setFlash] = useState(FlashMode.off);

  const scanLineAnim = useRef(new Animated.Value(0)).current;
  const detectedAnim = useRef(new Animated.Value(0)).current;
  const timerRef = useRef(null);

  const presetCategory = route?.params?.category;

  // ── Permissions ─────────────────────────────────────────────────
  useEffect(() => {
    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === 'granted');
    })();
  }, []);

  // ── 60-second countdown ──────────────────────────────────────────
  useEffect(() => {
    if (timerActive) {
      timerRef.current = setInterval(() => {
        setTimeLeft((t) => {
          if (t <= 1) {
            clearInterval(timerRef.current);
            handleTimeout();
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [timerActive]);

  const handleTimeout = () => {
    Vibration.vibrate(200);
    Alert.alert('Time Up', 'Your 60-second window has expired. Please try again.', [
      { text: 'Retry', onPress: resetSession },
      { text: 'Go Back', onPress: () => navigation.goBack() },
    ]);
  };

  const resetSession = () => {
    setDetected(null);
    setScanning(false);
    setTimeLeft(TIMEOUT_SECS);
    setTimerActive(false);
  };

  // ── Scan line animation ──────────────────────────────────────────
  const startScanAnimation = useCallback(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(scanLineAnim, { toValue: 1, duration: 1400, useNativeDriver: true }),
        Animated.timing(scanLineAnim, { toValue: 0, duration: 1400, useNativeDriver: true }),
      ])
    ).start();
  }, [scanLineAnim]);

  // ── AI Scan ──────────────────────────────────────────────────────
  const handleAIScan = async () => {
    if (!cameraRef.current) return;
    setScanning(true);
    setTimerActive(true);
    startScanAnimation();

    try {
      // Capture photo from live camera
      const photo = await cameraRef.current.takePictureAsync({
        quality: 0.8,
        base64: false,
        skipProcessing: false,
      });

      // Simulate AI processing (replace with your AI API call)
      await new Promise((r) => setTimeout(r, 1800));
      const aiResult = simulateAIDetection(presetCategory || 'food');

      setScanning(false);
      setDetected({ ...aiResult, imageUri: photo.uri });

      // Animate in
      Animated.spring(detectedAnim, { toValue: 1, useNativeDriver: true, tension: 100, friction: 8 }).start();

      // Store image URI in draft
      dispatch(updateDraft({ imageUri: photo.uri, aiDetected: aiResult, category: presetCategory || 'food' }));
      Vibration.vibrate(100);
    } catch (err) {
      setScanning(false);
      Alert.alert('Scan Failed', 'Could not scan item. Please try again.');
    }
  };

  // ── Barcode scan result ──────────────────────────────────────────
  const handleBarcodeScanned = ({ type, data }) => {
    if (detected) return;
    Vibration.vibrate(100);
    setDetected({ name: `Barcode: ${data}`, category: 'General', confidence: 100, barcode: data });
    dispatch(updateDraft({ barcode: data, category: presetCategory || 'ecommerce' }));
  };

  // ── Proceed to listing ───────────────────────────────────────────
  const handleProceed = async () => {
    if (!detected?.imageUri) {
      navigation.navigate('Listing');
      return;
    }
    setUploading(true);
    try {
      const result = await uploadListingImage(detected.imageUri, uid, (p) => setUploadProgress(p));
      dispatch(updateDraft({ imageUrl: result.url, imagePath: result.path }));
      navigation.navigate('Listing');
    } catch (err) {
      Alert.alert('Upload Failed', 'Image upload failed. Proceeding without image.');
      navigation.navigate('Listing');
    } finally {
      setUploading(false);
    }
  };

  if (hasPermission === null) {
    return <View style={styles.root}><Text style={{ color: colors.muted, marginTop: 100, textAlign: 'center' }}>Requesting camera...</Text></View>;
  }
  if (hasPermission === false) {
    return (
      <View style={styles.root}>
        <Text style={styles.permText}>Camera permission required for listing.</Text>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.permBtn}>
          <Text style={{ color: colors.bg, fontWeight: '700' }}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const scanLineTranslate = scanLineAnim.interpolate({ inputRange: [0, 1], outputRange: [-150, 150] });

  return (
    <View style={styles.root}>
      {/* ── Camera Viewport ── */}
      <View style={styles.cameraWrap}>
        <Camera
          ref={cameraRef}
          style={styles.camera}
          type={CameraType.back}
          flashMode={flash}
          onBarCodeScanned={mode === 'barcode' ? handleBarcodeScanned : undefined}
        >
          {/* Corner guides */}
          <View style={StyleSheet.absoluteFill}>
            {[['top', 'left'], ['top', 'right'], ['bottom', 'left'], ['bottom', 'right']].map(([v, h]) => (
              <View key={`${v}${h}`} style={[styles.corner, styles[`corner_${v}_${h}`]]} />
            ))}

            {/* AI scan overlay */}
            {scanning && (
              <View style={styles.scanOverlay}>
                {/* Scan grid */}
                <View style={styles.scanGrid} />
                {/* Moving scan line */}
                <Animated.View style={[styles.scanLine, { transform: [{ translateY: scanLineTranslate }] }]} />
                <View style={styles.aiLabel}>
                  <View style={styles.aiDot} />
                  <Text style={styles.aiText}>AI SCANNING</Text>
                </View>
              </View>
            )}

            {/* Detected result */}
            {detected && (
              <Animated.View style={[styles.detectedCard, { transform: [{ scale: detectedAnim }], opacity: detectedAnim }]}>
                <View style={styles.detectedIcon}>
                  <Text style={{ fontSize: 28 }}>🌾</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.detectedName}>{detected.name}</Text>
                  <Text style={styles.detectedCategory}>{detected.category}</Text>
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={styles.detectedConf}>{detected.confidence}%</Text>
                  <Text style={{ fontSize: 10, color: colors.muted }}>confidence</Text>
                </View>
              </Animated.View>
            )}

            {/* Timer */}
            {timerActive && (
              <View style={styles.timer}>
                <Text style={[styles.timerText, timeLeft <= 10 && { color: colors.urgent }]}>
                  ⏱ {timeLeft}s
                </Text>
              </View>
            )}

            {/* Barcode label */}
            {mode === 'barcode' && (
              <View style={styles.barcodeHint}>
                <Text style={styles.barcodeHintText}>Align barcode within frame</Text>
              </View>
            )}
          </View>
        </Camera>
      </View>

      {/* ── Gallery Disabled Notice ── */}
      <View style={styles.galleryDisabled}>
        <Text style={{ fontSize: 16 }}>🔒</Text>
        <View style={{ flex: 1 }}>
          <Text style={styles.galleryTitle}>Gallery uploads disabled</Text>
          <Text style={styles.gallerySub}>Live camera only — ensures listing authenticity</Text>
        </View>
        <View style={styles.trustBadge}><Text style={styles.trustText}>TRUST ✓</Text></View>
      </View>

      {/* ── Mode Toggle ── */}
      <View style={styles.modeToggle}>
        {['scan', 'barcode'].map((m) => (
          <TouchableOpacity key={m} onPress={() => setMode(m)} style={[styles.modeBtn, mode === m && styles.modeBtnActive]} activeOpacity={0.7}>
            <Text style={[styles.modeBtnText, { color: mode === m ? colors.bg : colors.muted }]}>
              {m === 'scan' ? '📷 AI Scan' : '📊 Barcode'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* ── Controls ── */}
      <View style={styles.controls}>
        <TouchableOpacity style={styles.flashBtn} onPress={() => setFlash(flash === FlashMode.off ? FlashMode.on : FlashMode.off)} activeOpacity={0.7}>
          <Text style={{ fontSize: 20 }}>{flash === FlashMode.on ? '⚡' : '🔦'}</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.actionBtn, (detected || scanning || uploading) && styles.actionBtnDim]}
          onPress={detected ? handleProceed : handleAIScan}
          activeOpacity={0.85}
          disabled={scanning}
        >
          <LinearGradient colors={[colors.accentDark, colors.accent]} style={styles.actionBtnGrad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
            <Text style={styles.actionBtnText}>
              {uploading ? `Uploading ${uploadProgress}%` : scanning ? 'Scanning...' : detected ? '✓ Proceed →' : 'Start AI Scan'}
            </Text>
          </LinearGradient>
        </TouchableOpacity>

        <TouchableOpacity style={styles.flashBtn} onPress={resetSession} activeOpacity={0.7}>
          <Text style={{ fontSize: 20 }}>🔄</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.hint}>⏱ 60-second listing window • Position item clearly in frame</Text>

      {/* Back button */}
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn} activeOpacity={0.7}>
        <Text style={styles.backBtnText}>←</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  cameraWrap: { margin: 16, borderRadius: 28, overflow: 'hidden', height: height * 0.48 },
  camera: { flex: 1 },
  corner: { position: 'absolute', width: 28, height: 28 },
  corner_top_left: { top: 20, left: 20, borderTopWidth: 3, borderLeftWidth: 3, borderColor: colors.accent, borderTopLeftRadius: 8 },
  corner_top_right: { top: 20, right: 20, borderTopWidth: 3, borderRightWidth: 3, borderColor: colors.accent, borderTopRightRadius: 8 },
  corner_bottom_left: { bottom: 20, left: 20, borderBottomWidth: 3, borderLeftWidth: 3, borderColor: colors.accent, borderBottomLeftRadius: 8 },
  corner_bottom_right: { bottom: 20, right: 20, borderBottomWidth: 3, borderRightWidth: 3, borderColor: colors.accent, borderBottomRightRadius: 8 },
  scanOverlay: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  scanGrid: { ...StyleSheet.absoluteFillObject, opacity: 0.12 },
  scanLine: { position: 'absolute', left: 20, right: 20, height: 2, backgroundColor: colors.accent, shadowColor: colors.accent, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 1, shadowRadius: 8 },
  aiLabel: { position: 'absolute', top: 16, right: 16, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: `${colors.accent}20`, borderWidth: 1, borderColor: `${colors.accent}50`, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 6 },
  aiDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.accent },
  aiText: { fontSize: 11, color: colors.accent, fontWeight: '700', letterSpacing: 0.5 },
  detectedCard: { position: 'absolute', bottom: 16, left: 16, right: 16, backgroundColor: 'rgba(13,26,15,0.95)', borderWidth: 1, borderColor: `${colors.accent}50`, borderRadius: 16, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 12 },
  detectedIcon: { width: 44, height: 44, borderRadius: 12, backgroundColor: colors.accentDim, alignItems: 'center', justifyContent: 'center' },
  detectedName: { fontSize: 13, fontWeight: '600', color: colors.text },
  detectedCategory: { fontSize: 11, color: colors.muted, marginTop: 2 },
  detectedConf: { fontSize: 18, fontWeight: '800', color: colors.accent },
  timer: { position: 'absolute', top: 16, left: 16, backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 5 },
  timerText: { fontSize: 12, color: colors.text, fontWeight: '700' },
  barcodeHint: { position: 'absolute', bottom: 60, alignSelf: 'center', backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 },
  barcodeHintText: { fontSize: 12, color: colors.text },
  galleryDisabled: { flexDirection: 'row', alignItems: 'center', gap: 10, marginHorizontal: 16, backgroundColor: colors.urgentBg, borderWidth: 1, borderColor: '#FF5C3530', borderRadius: 12, padding: spacing.md },
  galleryTitle: { fontSize: 12, color: colors.urgent, fontWeight: '700' },
  gallerySub: { fontSize: 10, color: '#FF5C3580', marginTop: 1 },
  trustBadge: { backgroundColor: '#FF5C3520', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 },
  trustText: { fontSize: 10, color: colors.urgent, fontWeight: '700' },
  modeToggle: { flexDirection: 'row', margin: 16, marginTop: 12, backgroundColor: colors.card, borderRadius: 16, padding: 4, borderWidth: 1, borderColor: colors.border },
  modeBtn: { flex: 1, padding: 10, borderRadius: 12, alignItems: 'center' },
  modeBtnActive: { backgroundColor: colors.accent },
  modeBtnText: { fontWeight: '700', fontSize: 13 },
  controls: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16, gap: 12 },
  flashBtn: { width: 46, height: 46, borderRadius: 23, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
  actionBtn: { flex: 1, borderRadius: 18, overflow: 'hidden' },
  actionBtnDim: { opacity: 0.85 },
  actionBtnGrad: { paddingVertical: 16, alignItems: 'center' },
  actionBtnText: { fontSize: 15, color: colors.bg, fontWeight: '800', letterSpacing: -0.2 },
  hint: { textAlign: 'center', fontSize: 11, color: colors.muted, marginTop: 10, marginHorizontal: 20 },
  backBtn: { position: 'absolute', top: 56, left: 24, width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(0,0,0,0.5)', borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
  backBtnText: { color: colors.text, fontSize: 18, fontWeight: '600' },
  permText: { color: colors.muted, textAlign: 'center', marginTop: 120, marginHorizontal: 40, fontSize: 14, lineHeight: 22 },
  permBtn: { alignSelf: 'center', marginTop: 20, backgroundColor: colors.accent, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 },
});
