// src/screens/RegisterScreen.js
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, Alert, ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { registerUser } from '../firebase/auth';
import { useDispatch } from 'react-redux';
import { setFirebaseUser } from '../store/userSlice';
import { colors, spacing, radius, shadows } from '../utils/theme';
import { USER_ROLES } from '../utils/constants';

const ROLES = [
  { id: USER_ROLES.FARMER, label: 'Farmer', icon: '🌾', desc: 'Crop residue, produce' },
  { id: USER_ROLES.CONSUMER, label: 'Consumer', icon: '🏪', desc: 'Returns, excess goods' },
  { id: USER_ROLES.SHG, label: 'SHG', icon: '👥', desc: 'Self-help group' },
  { id: USER_ROLES.TRANSPORTER, label: 'Transporter', icon: '🚛', desc: 'Pickup & delivery' },
];

export default function RegisterScreen({ navigation }) {
  const dispatch = useDispatch();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleRegister = async () => {
    if (!name || !email || !password || !role) {
      Alert.alert('Missing Fields', 'Please fill all fields and select your role.');
      return;
    }
    if (password.length < 6) {
      Alert.alert('Weak Password', 'Password must be at least 6 characters.');
      return;
    }
    setLoading(true);
    try {
      const user = await registerUser({ email: email.trim(), password, name: name.trim(), role, phone });
      dispatch(setFirebaseUser({ uid: user.uid, email: user.email, displayName: user.displayName }));
    } catch (err) {
      let msg = 'Registration failed.';
      if (err.code === 'auth/email-already-in-use') msg = 'Email already registered.';
      if (err.code === 'auth/invalid-email') msg = 'Invalid email address.';
      Alert.alert('Registration Failed', msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <LinearGradient colors={[colors.bgDeep, colors.bg]} style={styles.bg}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={styles.headerRow}>
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
              <Text style={styles.backText}>←</Text>
            </TouchableOpacity>
            <Text style={styles.pageTitle}>Join RegenX</Text>
          </View>

          <View style={styles.form}>
            <Text style={styles.formTitle}>Create Account</Text>

            {[
              { label: 'Full Name', value: name, set: setName, placeholder: 'Priya Sharma', type: 'default' },
              { label: 'Email', value: email, set: setEmail, placeholder: 'you@example.com', type: 'email-address' },
              { label: 'Phone (optional)', value: phone, set: setPhone, placeholder: '+91 98765 43210', type: 'phone-pad' },
              { label: 'Password', value: password, set: setPassword, placeholder: '••••••••', secure: true },
            ].map((f) => (
              <View key={f.label} style={styles.inputWrap}>
                <Text style={styles.inputLabel}>{f.label}</Text>
                <TextInput
                  style={styles.input}
                  value={f.value}
                  onChangeText={f.set}
                  placeholder={f.placeholder}
                  placeholderTextColor={colors.muted}
                  keyboardType={f.type || 'default'}
                  secureTextEntry={f.secure}
                  autoCapitalize={f.type === 'email-address' ? 'none' : 'words'}
                  selectionColor={colors.accent}
                />
              </View>
            ))}

            {/* Role selector */}
            <Text style={[styles.inputLabel, { marginBottom: 10 }]}>I am a...</Text>
            <View style={styles.roleGrid}>
              {ROLES.map((r) => (
                <TouchableOpacity
                  key={r.id}
                  onPress={() => setRole(r.id)}
                  style={[styles.roleCard, role === r.id && styles.roleCardActive]}
                  activeOpacity={0.7}
                >
                  <Text style={styles.roleIcon}>{r.icon}</Text>
                  <Text style={[styles.roleLabel, role === r.id && { color: colors.accent }]}>{r.label}</Text>
                  <Text style={styles.roleDesc}>{r.desc}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity onPress={handleRegister} disabled={loading} activeOpacity={0.85} style={{ borderRadius: radius.xl, overflow: 'hidden', marginTop: spacing.base, ...shadows.accent }}>
              <LinearGradient colors={[colors.accentDark, colors.accent]} style={styles.submitBtn}>
                <Text style={styles.submitText}>{loading ? '⏳ Creating account...' : '🌱 Create Account'}</Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => navigation.navigate('Login')} style={styles.loginLink} activeOpacity={0.7}>
              <Text style={styles.loginLinkText}>Already have an account? <Text style={{ color: colors.accent, fontWeight: '700' }}>Sign in →</Text></Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </LinearGradient>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  bg: { flex: 1 },
  content: { flexGrow: 1, padding: spacing.xl, paddingTop: 56 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 16, marginBottom: spacing.xl },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
  backText: { color: colors.text, fontSize: 18 },
  pageTitle: { fontSize: 20, color: colors.text, fontWeight: '800' },
  form: { backgroundColor: colors.card, borderRadius: 28, padding: spacing.xl, borderWidth: 1, borderColor: colors.border },
  formTitle: { fontSize: 20, color: colors.text, fontWeight: '800', marginBottom: spacing.xl },
  inputWrap: { marginBottom: spacing.base },
  inputLabel: { fontSize: 11, color: colors.muted, letterSpacing: 1, textTransform: 'uppercase', fontWeight: '700', marginBottom: 6 },
  input: { backgroundColor: colors.cardAlt, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.base, color: colors.text, fontSize: 15 },
  roleGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: spacing.base },
  roleCard: { width: '47%', backgroundColor: colors.cardAlt, borderWidth: 1, borderColor: colors.border, borderRadius: radius.lg, padding: 12, alignItems: 'center', gap: 4 },
  roleCardActive: { borderColor: colors.accent, backgroundColor: colors.accentDim },
  roleIcon: { fontSize: 24 },
  roleLabel: { fontSize: 13, color: colors.text, fontWeight: '700' },
  roleDesc: { fontSize: 10, color: colors.muted, textAlign: 'center' },
  submitBtn: { paddingVertical: 16, alignItems: 'center', borderRadius: radius.xl },
  submitText: { fontSize: 16, color: colors.bg, fontWeight: '800' },
  loginLink: { alignItems: 'center', marginTop: spacing.base },
  loginLinkText: { fontSize: 13, color: colors.muted },
});
