// src/screens/NoBuyerScreen.js
import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Animated, Alert, Linking,
} from 'react-native';
import MapView, { Marker, Circle } from 'react-native-maps';
import { LinearGradient } from 'expo-linear-gradient';
import * as Location from 'expo-location';
import { useDispatch, useSelector } from 'react-redux';
import { relistItem, donateItem, selectNoBuyerItems } from '../store/listingsSlice';
import { getVerifiedNGOs, getRecyclingCentres } from '../firebase/firestore';
import { useAuth } from '../hooks/useAuth';
import { colors, spacing, radius, shadows } from '../utils/theme';
import { POINTS } from '../utils/constants';
import { formatDistance, formatPrice } from '../utils/helpers';

// Sample recycling centres (will be fetched from Firestore in prod)
const MOCK_RECYCLING = [
  { id: 'r1', name: 'GreenHub Recycling', distance: 800, lat: 12.9720, lng: 80.2210, open: true, type: '♻' },
  { id: 'r2', name: 'EcoSort Station', distance: 1400, lat: 12.9680, lng: 80.2250, open: true, type: '♻' },
  { id: 'r3', name: 'e-Waste Depot', distance: 2100, lat: 12.9640, lng: 80.2180, open: false, type: '🔌' },
];

const MOCK_NGOS = [
  { id: 'n1', name: 'Sadahar Food Bank', accepts: ['food'], freePickup: true, verified: true },
  { id: 'n2', name: 'Gyan Jyoti Trust', accepts: ['food', 'medicine', 'textile'], freePickup: true, verified: true },
];

export default function NoBuyerScreen({ navigation, route }) {
  const dispatch = useDispatch();
  const { uid } = useAuth();
  const noBuyerItems = useSelector(selectNoBuyerItems);
  const listingId = route?.params?.listingId;
  const listing = noBuyerItems.find((l) => l.id === listingId) || noBuyerItems[0];

  const [mapExpanded, setMapExpanded] = useState(false);
  const [relistPrice, setRelistPrice] = useState(null);
  const [userLocation, setUserLocation] = useState(null);
  const [ngos, setNgos] = useState(MOCK_NGOS);
  const [recyclingCentres, setRecyclingCentres] = useState(MOCK_RECYCLING);
  const [loading, setLoading] = useState({ relist: false, donate: false, recycle: false });

  const mapHeight = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const originalPrice = listing?.price || 250;
  const suggestedPrice = Math.round(originalPrice * 0.7);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
    fetchLocation();
  }, []);

  const fetchLocation = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status === 'granted') {
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      setUserLocation(loc.coords);
    }
  };

  const toggleMap = () => {
    setMapExpanded(!mapExpanded);
    Animated.spring(mapHeight, {
      toValue: mapExpanded ? 0 : 220,
      useNativeDriver: false,
      tension: 80,
      friction: 12,
    }).start();
  };

  // ── Action 1: Relist ─────────────────────────────────────────────
  const handleRelist = async (price) => {
    setLoading((l) => ({ ...l, relist: true }));
    try {
      await dispatch(relistItem({ listingId: listing?.id, newPrice: price, uid })).unwrap();
      Alert.alert('✅ Relisted!', `Your item is live again at ₹${price}. You earned +${POINTS.RELIST} Regen Points!`, [
        { text: 'Great!', onPress: () => navigation.goBack() },
      ]);
    } catch (err) {
      Alert.alert('Error', 'Could not relist. Please try again.');
    } finally {
      setLoading((l) => ({ ...l, relist: false }));
    }
  };

  // ── Action 2: Donate ─────────────────────────────────────────────
  const handleDonate = async (ngo) => {
    setLoading((l) => ({ ...l, donate: true }));
    try {
      await dispatch(donateItem({ listingId: listing?.id, ngoId: ngo.id, uid })).unwrap();
      Alert.alert('💙 Donated!', `Donation scheduled with ${ngo.name}. Free pickup arranged! +${POINTS.DONATION} Regen Points earned.`, [
        { text: 'Thank you!', onPress: () => navigation.goBack() },
      ]);
    } catch (err) {
      Alert.alert('Error', 'Could not schedule donation. Please try again.');
    } finally {
      setLoading((l) => ({ ...l, donate: false }));
    }
  };

  // ── Action 3: Navigate ────────────────────────────────────────────
  const openMapsNavigation = (centre) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${centre.lat},${centre.lng}&travelmode=driving`;
    Linking.openURL(url);
  };

  return (
    <Animated.View style={[styles.root, { opacity: fadeAnim }]}>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* ── Header ── */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Text style={styles.backText}>←</Text>
          </TouchableOpacity>
          <View style={{ flex: 1 }}>
            <Text style={styles.title}>No Buyer Found</Text>
            <Text style={styles.subtitle}>{listing?.itemName || 'Your Item'} · Listed 7 days ago</Text>
          </View>
        </View>

        {/* ── Hero Card ── */}
        <LinearGradient colors={['#F5C84215', '#7FEA5A08']} style={styles.heroCard}>
          <LinearGradient colors={['transparent', 'transparent']} style={{}}>
            <View style={styles.heroTop}>
              <Text style={{ fontSize: 42 }}>⌛</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.heroTitle}>7 Days Without a Buyer</Text>
                <Text style={styles.heroSub}>Don't let this go to waste. Each option earns Regen Points.</Text>
              </View>
            </View>
            <View style={styles.statsRow}>
              {[
                { val: '7', label: 'days', color: colors.accent },
                { val: listing?.views || 24, label: 'views', color: colors.gold },
                { val: listing?.inquiries || 3, label: 'inquiries', color: colors.blue },
                { val: formatPrice(listing?.price), label: 'asking', color: colors.text },
              ].map((s) => (
                <View key={s.label} style={styles.statCard}>
                  <Text style={[styles.statVal, { color: s.color }]}>{s.val}</Text>
                  <Text style={styles.statLabel}>{s.label}</Text>
                </View>
              ))}
            </View>
          </LinearGradient>
        </LinearGradient>

        {/* ── Action 1: Relist ── */}
        <View style={styles.actionSection}>
          <View style={styles.actionCard}>
            <View style={[styles.actionIconWrap, { backgroundColor: colors.goldBg, borderColor: '#F5C84230' }]}>
              <Text style={{ fontSize: 24 }}>🏷</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.actionTitle}>Relist at Lower Price</Text>
              <Text style={styles.actionSub}>Suggested: ₹{suggestedPrice} (30% off) • Boost visibility</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.priceRow}>
                {[originalPrice, suggestedPrice, Math.round(originalPrice * 0.6), Math.round(originalPrice * 0.4)].map((p) => {
                  const isSuggested = p === suggestedPrice;
                  return (
                    <TouchableOpacity key={p} onPress={() => setRelistPrice(p)} style={[styles.priceChip, relistPrice === p && styles.priceChipActive, isSuggested && styles.priceChipSuggested]} activeOpacity={0.7}>
                      <Text style={[styles.priceChipText, (relistPrice === p || isSuggested) && styles.priceChipTextActive]}>₹{p}</Text>
                      {isSuggested && <Text style={styles.suggestedLabel}>suggested</Text>}
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </View>
          </View>
          <TouchableOpacity
            onPress={() => handleRelist(relistPrice || suggestedPrice)}
            disabled={loading.relist}
            activeOpacity={0.85}
            style={{ borderRadius: radius.lg, overflow: 'hidden', marginTop: 8 }}
          >
            <LinearGradient colors={[colors.gold, '#E6A800']} style={styles.actionBtn} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
              <Text style={styles.actionBtnText}>
                {loading.relist ? '⏳ Relisting...' : `Relist at ₹${relistPrice || suggestedPrice} → +${POINTS.RELIST} pts`}
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* ── Action 2: Donate ── */}
        <View style={styles.actionSection}>
          <View style={styles.actionCard}>
            <View style={[styles.actionIconWrap, { backgroundColor: colors.blueBg, borderColor: '#5ABAFF25' }]}>
              <Text style={{ fontSize: 24 }}>💙</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.actionTitle}>Donate to Verified NGO</Text>
              <View style={styles.ngoList}>
                {ngos.map((ngo) => (
                  <View key={ngo.id} style={styles.ngoRow}>
                    <Text style={styles.ngoName}>{ngo.name}</Text>
                    <View style={styles.ngoBadges}>
                      <View style={[styles.badge, { backgroundColor: colors.accentDim }]}>
                        <Text style={[styles.badgeText, { color: colors.accent }]}>✓ Verified</Text>
                      </View>
                      {ngo.freePickup && (
                        <View style={[styles.badge, { backgroundColor: colors.blueBg }]}>
                          <Text style={[styles.badgeText, { color: colors.blue }]}>🚚 Free Pickup</Text>
                        </View>
                      )}
                    </View>
                  </View>
                ))}
              </View>
            </View>
          </View>
          <TouchableOpacity
            onPress={() => handleDonate(ngos[0])}
            disabled={loading.donate}
            activeOpacity={0.85}
            style={{ borderRadius: radius.lg, overflow: 'hidden', marginTop: 8 }}
          >
            <LinearGradient colors={[colors.blue, '#2196F3']} style={styles.actionBtn} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
              <Text style={[styles.actionBtnText, { color: '#001833' }]}>
                {loading.donate ? '⏳ Scheduling...' : `Schedule Donation Pickup → +${POINTS.DONATION} pts`}
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* ── Action 3: Recycling + Map ── */}
        <View style={[styles.actionSection, { paddingBottom: 100 }]}>
          <View style={[styles.actionCard, { flexDirection: 'column', gap: 0 }]}>
            <View style={{ flexDirection: 'row', gap: 14 }}>
              <View style={[styles.actionIconWrap, { backgroundColor: colors.accentDim, borderColor: '#7FEA5A25' }]}>
                <Text style={{ fontSize: 24 }}>♻</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.actionTitle}>Locate Nearest Recycling Point</Text>
                <Text style={styles.actionSub}>{recyclingCentres.length} certified centres nearby</Text>
                <View style={styles.ngoBadges}>
                  <View style={[styles.badge, { backgroundColor: colors.accentDim }]}>
                    <Text style={[styles.badgeText, { color: colors.accent }]}>📍 {formatDistance(recyclingCentres[0]?.distance || 800)}</Text>
                  </View>
                  <View style={[styles.badge, { backgroundColor: '#B97FFF15' }]}>
                    <Text style={[styles.badgeText, { color: '#B97FFF' }]}>Open now</Text>
                  </View>
                </View>
              </View>
              <TouchableOpacity onPress={toggleMap} style={styles.mapToggleBtn} activeOpacity={0.7}>
                <Text style={styles.mapToggleText}>{mapExpanded ? '↑ Hide' : 'Map'}</Text>
              </TouchableOpacity>
            </View>

            {/* Collapsible Mini Map */}
            <Animated.View style={[styles.mapWrap, { height: mapHeight, overflow: 'hidden' }]}>
              {userLocation && (
                <MapView
                  style={styles.map}
                  initialRegion={{
                    latitude: userLocation.latitude,
                    longitude: userLocation.longitude,
                    latitudeDelta: 0.02,
                    longitudeDelta: 0.02,
                  }}
                  customMapStyle={darkMapStyle}
                >
                  {/* User location */}
                  <Marker coordinate={{ latitude: userLocation.latitude, longitude: userLocation.longitude }}>
                    <View style={styles.userMarker} />
                  </Marker>

                  {/* Recycling centres */}
                  {recyclingCentres.map((c) => (
                    <Marker
                      key={c.id}
                      coordinate={{ latitude: c.lat, longitude: c.lng }}
                      title={c.name}
                      description={formatDistance(c.distance)}
                      onCalloutPress={() => openMapsNavigation(c)}
                    >
                      <View style={styles.recycleMarker}>
                        <Text style={{ fontSize: 16 }}>{c.type}</Text>
                      </View>
                    </Marker>
                  ))}
                </MapView>
              )}

              {/* Recycling centre list */}
              <View style={styles.centreList}>
                {recyclingCentres.map((c) => (
                  <TouchableOpacity key={c.id} style={styles.centreRow} onPress={() => openMapsNavigation(c)} activeOpacity={0.7}>
                    <Text style={{ fontSize: 18 }}>{c.type}</Text>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.centreName}>{c.name}</Text>
                      <Text style={styles.centreDist}>{formatDistance(c.distance)}</Text>
                    </View>
                    <Text style={[styles.centreStatus, { color: c.open ? colors.accent : colors.muted }]}>
                      {c.open ? 'Open' : 'Closed'}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </Animated.View>
          </View>

          <TouchableOpacity
            onPress={() => { openMapsNavigation(recyclingCentres[0]); }}
            activeOpacity={0.85}
            style={{ borderRadius: radius.lg, overflow: 'hidden', marginTop: 8, ...shadows.accent }}
          >
            <LinearGradient colors={[colors.accentDark, colors.accent]} style={styles.actionBtn} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
              <Text style={styles.actionBtnText}>Navigate to {recyclingCentres[0]?.name} → +{POINTS.RECYCLING} pts</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </Animated.View>
  );
}

// Dark map style for Google Maps
const darkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#0D1A0F' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#6B8F72' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#0D1A0F' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#1A2D1E' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#2A4530' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#060D07' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#132016' }] },
];

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  scroll: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: spacing.xl, paddingTop: 52 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
  backText: { color: colors.text, fontSize: 18 },
  title: { fontSize: 18, color: colors.text, fontWeight: '800' },
  subtitle: { fontSize: 12, color: colors.muted, marginTop: 1 },
  heroCard: { marginHorizontal: spacing.lg, marginBottom: spacing.lg, borderRadius: radius.xxl, padding: spacing.lg, borderWidth: 1, borderColor: '#F5C84230' },
  heroTop: { flexDirection: 'row', gap: 14, alignItems: 'flex-start', marginBottom: spacing.base },
  heroTitle: { fontSize: 16, color: colors.text, fontWeight: '800', marginBottom: 5 },
  heroSub: { fontSize: 13, color: colors.textDim, lineHeight: 20 },
  statsRow: { flexDirection: 'row', gap: 8 },
  statCard: { flex: 1, backgroundColor: 'rgba(0,0,0,0.2)', borderRadius: 12, padding: 10, alignItems: 'center' },
  statVal: { fontSize: 18, fontWeight: '800', lineHeight: 22 },
  statLabel: { fontSize: 10, color: colors.muted, marginTop: 2 },
  actionSection: { paddingHorizontal: spacing.lg, marginBottom: 12 },
  actionCard: { flexDirection: 'row', gap: 14, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: radius.xxl, padding: spacing.base },
  actionIconWrap: { width: 52, height: 52, borderRadius: 18, borderWidth: 1, alignItems: 'center', justifyContent: 'center', flexShrink: 0, alignSelf: 'flex-start', marginTop: 2 },
  actionTitle: { fontSize: 15, color: colors.text, fontWeight: '700', marginBottom: 3 },
  actionSub: { fontSize: 12, color: colors.muted, lineHeight: 18, marginBottom: 8 },
  priceRow: { flexDirection: 'row', gap: 6, paddingRight: spacing.base },
  priceChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10, backgroundColor: colors.cardAlt, borderWidth: 1, borderColor: colors.border },
  priceChipActive: { borderColor: colors.gold, backgroundColor: colors.goldBg },
  priceChipSuggested: { borderColor: '#F5C84240', backgroundColor: colors.goldBg },
  priceChipText: { fontSize: 12, color: colors.muted, fontWeight: '500' },
  priceChipTextActive: { color: colors.gold, fontWeight: '700' },
  suggestedLabel: { fontSize: 8, color: colors.gold, marginTop: 2 },
  ngoList: { gap: 8 },
  ngoRow: { gap: 4 },
  ngoName: { fontSize: 13, color: colors.text, fontWeight: '600' },
  ngoBadges: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 4 },
  badge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.full },
  badgeText: { fontSize: 10, fontWeight: '600' },
  mapToggleBtn: { backgroundColor: colors.cardAlt, borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6, alignSelf: 'flex-start' },
  mapToggleText: { fontSize: 11, color: colors.accent, fontWeight: '700' },
  mapWrap: { marginTop: spacing.base, borderRadius: 16, overflow: 'hidden' },
  map: { width: '100%', height: 180 },
  userMarker: { width: 14, height: 14, borderRadius: 7, backgroundColor: colors.blue, borderWidth: 2, borderColor: '#fff', shadowColor: colors.blue, shadowRadius: 8, shadowOpacity: 0.8, shadowOffset: { width: 0, height: 0 } },
  recycleMarker: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.accent, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: colors.bg, shadowColor: colors.accent, shadowRadius: 8, shadowOpacity: 0.6, shadowOffset: { width: 0, height: 0 } },
  centreList: { padding: spacing.md, gap: 8 },
  centreRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: 'rgba(255,255,255,0.04)', borderRadius: 12, padding: 10 },
  centreName: { fontSize: 12, color: colors.text, fontWeight: '600' },
  centreDist: { fontSize: 11, color: colors.accent, marginTop: 1 },
  centreStatus: { fontSize: 11, fontWeight: '600' },
  actionBtn: { paddingVertical: 14, alignItems: 'center', borderRadius: radius.lg },
  actionBtnText: { fontSize: 13, color: colors.bg, fontWeight: '800', letterSpacing: -0.2, textAlign: 'center', paddingHorizontal: 8 },
});
