// src/screens/ListingScreen.js
import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  StyleSheet, Animated, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useDispatch, useSelector } from 'react-redux';
import { selectDraftListing, submitListing, selectSubmitting, clearDraft } from '../store/listingsSlice';
import { useAuth } from '../hooks/useAuth';
import { colors, spacing, radius, shadows } from '../utils/theme';
import { CONDITIONS, ITEM_CATEGORIES } from '../utils/constants';
import { isUrgentExpiry, estimatePoints, formatPrice, validateListingForm } from '../utils/helpers';

const YEARS = ['2020', '2021', '2022', '2023', '2024', '2025'];
const QUICK_PRICES = ['Free', '50', '100', '200', '500'];
const EXPIRY_OPTIONS = [
  { value: '1', label: '1', sub: 'URGENT' },
  { value: '2', label: '2', sub: 'URGENT' },
  { value: '3', label: '3', sub: null },
  { value: '7', label: '7+', sub: null },
];

export default function ListingScreen({ navigation }) {
  const dispatch = useDispatch();
  const { uid } = useAuth();
  const draft = useSelector(selectDraftListing);
  const submitting = useSelector(selectSubmitting);

  const [condition, setCondition] = useState('Good');
  const [year, setYear] = useState('2023');
  const [price, setPrice] = useState('250');
  const [expiryDays, setExpiry] = useState(null);
  const [description, setDescription] = useState('');
  const [errors, setErrors] = useState({});

  const isFood = draft.category === 'food' || draft.category === 'medicine';
  const urgent = isUrgentExpiry(expiryDays, draft.category);
  const estimatedPts = estimatePoints({ category: draft.category, expiryDays, price, condition });

  const urgentAnim = useRef(new Animated.Value(1)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (urgent) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(urgentAnim, { toValue: 1.03, duration: 700, useNativeDriver: true }),
          Animated.timing(urgentAnim, { toValue: 1, duration: 700, useNativeDriver: true }),
        ])
      ).start();
    }
  }, [urgent]);

  const handleSubmit = async () => {
    const form = { condition, year, price, expiryDays: isFood ? expiryDays : null, category: draft.category };
    const { valid, errors: errs } = validateListingForm(form);
    if (!valid) { setErrors(errs); return; }
    setErrors({});

    const listingData = {
      condition,
      year: parseInt(year),
      price: parseInt(price) || 0,
      expiryDays: isFood ? parseInt(expiryDays) : null,
      description,
      category: draft.category || 'general',
      categoryLabel: draft.aiDetected?.category || 'General',
      itemName: draft.aiDetected?.name || 'Unlabeled Item',
      imageUrl: draft.imageUrl || null,
      imagePath: draft.imagePath || null,
      barcode: draft.barcode || null,
      aiConfidence: draft.aiDetected?.confidence || null,
    };

    try {
      const result = await dispatch(submitListing({ uid, data: listingData })).unwrap();
      dispatch(clearDraft());
      Alert.alert(
        urgent ? '🚨 Routed to NGO!' : '🌱 Listed!',
        urgent
          ? 'Your item has been auto-routed to a food NGO for pickup today. You earned bonus points!'
          : `Your listing is live! You earned +${estimatedPts} Regen Points.`,
        [{ text: 'Great!', onPress: () => navigation.navigate('HomeTabs') }]
      );
    } catch (err) {
      Alert.alert('Error', err || 'Submission failed. Please try again.');
    }
  };

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Animated.View style={{ flex: 1, opacity: fadeAnim }}>
        <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>

          {/* ── Header ── */}
          <View style={styles.header}>
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
              <Text style={styles.backText}>←</Text>
            </TouchableOpacity>
            <View style={{ flex: 1 }}>
              <Text style={styles.title}>List Your Item</Text>
              <Text style={styles.subtitle}>{draft.aiDetected?.name || 'Scanned Item'}</Text>
            </View>
            <CategoryBadge category={draft.category} />
          </View>

          {/* ── URGENT Banner ── */}
          {urgent && (
            <Animated.View style={[styles.urgentBanner, { transform: [{ scale: urgentAnim }] }]}>
              <Text style={{ fontSize: 28 }}>🚨</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.urgentTitle}>URGENT: AUTO-ROUTING TO FOOD NGO</Text>
                <Text style={styles.urgentSub}>
                  Expires in {expiryDays} day{expiryDays !== '1' ? 's' : ''} • Sadahar Food Bank will collect today
                </Text>
              </View>
              <View style={styles.urgentIcon}><Text style={{ fontSize: 20 }}>🍽</Text></View>
            </Animated.View>
          )}

          {/* ── 4 Questions ── */}
          <View style={styles.section}>
            <Text style={styles.heading}>4 Quick Questions</Text>
            <Text style={styles.subheading}>Every answer builds your Regen Score.</Text>

            {/* Q1: Condition */}
            <FormGroup label="① Condition" error={errors.condition}>
              <View style={styles.optionRow}>
                {CONDITIONS.map((c) => (
                  <TouchableOpacity
                    key={c}
                    onPress={() => setCondition(c)}
                    style={[styles.optionChip, condition === c && styles.optionChipActive]}
                    activeOpacity={0.7}
                  >
                    <Text style={[styles.optionText, condition === c && styles.optionTextActive]}>{c}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </FormGroup>

            {/* Q2: Purchase Year */}
            <FormGroup label="② Purchase Year" error={errors.year}>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.scrollRow}>
                {YEARS.map((y) => (
                  <TouchableOpacity
                    key={y}
                    onPress={() => setYear(y)}
                    style={[styles.yearChip, year === y && styles.yearChipActive]}
                    activeOpacity={0.7}
                  >
                    <Text style={[styles.yearText, year === y && styles.yearTextActive]}>{y}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </FormGroup>

            {/* Q3: Price */}
            <FormGroup label="③ Asking Price (₹)" error={errors.price}>
              <View style={styles.priceRow}>
                <Text style={styles.rupee}>₹</Text>
                <TextInput
                  style={styles.priceInput}
                  value={price}
                  onChangeText={setPrice}
                  keyboardType="numeric"
                  placeholderTextColor={colors.muted}
                  selectionColor={colors.accent}
                />
                <View style={styles.stepper}>
                  <TouchableOpacity onPress={() => setPrice(String(parseInt(price || 0) + 10))} style={styles.stepBtn}>
                    <Text style={styles.stepText}>+</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => setPrice(String(Math.max(0, parseInt(price || 0) - 10)))} style={styles.stepBtn}>
                    <Text style={styles.stepText}>−</Text>
                  </TouchableOpacity>
                </View>
              </View>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={[styles.scrollRow, { marginTop: 8 }]}>
                {QUICK_PRICES.map((p) => {
                  const val = p === 'Free' ? '0' : p;
                  return (
                    <TouchableOpacity
                      key={p}
                      onPress={() => setPrice(val)}
                      style={[styles.quickChip, price === val && styles.quickChipActive]}
                      activeOpacity={0.7}
                    >
                      <Text style={[styles.quickChipText, price === val && styles.quickChipTextActive]}>{p}</Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </FormGroup>

            {/* Q4: Expiry (food/medicine only) */}
            {isFood && (
              <FormGroup label="④ Expires In (days)" error={errors.expiryDays}>
                <View style={styles.optionRow}>
                  {EXPIRY_OPTIONS.map((opt) => {
                    const isUrg = opt.sub === 'URGENT';
                    const isSelected = expiryDays === opt.value;
                    return (
                      <TouchableOpacity
                        key={opt.value}
                        onPress={() => setExpiry(opt.value)}
                        style={[styles.expiryChip, isSelected && (isUrg ? styles.expiryUrgentActive : styles.expiryChipActive)]}
                        activeOpacity={0.7}
                      >
                        <Text style={[styles.expiryText, isSelected && (isUrg ? { color: colors.urgent } : { color: colors.accent })]}>
                          {opt.label}
                        </Text>
                        {opt.sub && <Text style={styles.expirySub}>{opt.sub}</Text>}
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </FormGroup>
            )}

            {/* Description */}
            <FormGroup label="Note (optional)">
              <TextInput
                style={styles.descInput}
                value={description}
                onChangeText={setDescription}
                placeholder="Any details buyers should know..."
                placeholderTextColor={colors.muted}
                multiline
                numberOfLines={3}
                selectionColor={colors.accent}
              />
            </FormGroup>

            {/* Points preview */}
            <View style={styles.pointsCard}>
              <Text style={{ fontSize: 28 }}>⚡</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.pointsLabel}>Estimated Regen Points</Text>
                <Text style={styles.pointsValue}>+{estimatedPts} pts</Text>
              </View>
              {urgent && (
                <View style={styles.bonusBadge}>
                  <Text style={styles.bonusText}>🚨 Urgency Bonus</Text>
                </View>
              )}
            </View>
          </View>

          {/* ── Submit ── */}
          <View style={styles.submitWrap}>
            <TouchableOpacity
              onPress={handleSubmit}
              disabled={submitting}
              activeOpacity={0.85}
              style={{ borderRadius: 20, overflow: 'hidden', ...shadows.accent }}
            >
              <LinearGradient
                colors={urgent ? ['#FF5C35', '#FF3D00'] : [colors.accentDark, colors.accent]}
                style={styles.submitBtn}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
              >
                <Text style={styles.submitText}>
                  {submitting ? '⏳ Publishing...' : urgent ? '🚨 Route to NGO Now' : '🌱 Publish Listing'}
                </Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </Animated.View>
    </KeyboardAvoidingView>
  );
}

function FormGroup({ label, error, children }) {
  return (
    <View style={styles.formGroup}>
      <Text style={styles.formLabel}>{label}</Text>
      {children}
      {error && <Text style={styles.formError}>{error}</Text>}
    </View>
  );
}

function CategoryBadge({ category }) {
  const cats = { food: ['🌾', colors.gold, colors.goldBg], crop_residue: ['🌾', colors.gold, colors.goldBg], ewaste: ['🔌', '#B97FFF', '#B97FFF20'], ecommerce: ['📦', colors.blue, colors.blueBg] };
  const [icon, color, bg] = cats[category] || ['📦', colors.muted, colors.card];
  return (
    <View style={[styles.catBadge, { backgroundColor: bg, borderColor: `${color}30` }]}>
      <Text style={{ fontSize: 12 }}>{icon}</Text>
      <Text style={[styles.catBadgeText, { color }]}>{category || 'General'}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  scroll: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: spacing.xl, paddingTop: 52, paddingBottom: spacing.base },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
  backText: { color: colors.text, fontSize: 18 },
  title: { fontSize: 18, color: colors.text, fontWeight: '800', letterSpacing: -0.3 },
  subtitle: { fontSize: 12, color: colors.muted, marginTop: 1 },
  catBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 4, borderRadius: radius.full, borderWidth: 1 },
  catBadgeText: { fontSize: 11, fontWeight: '600', textTransform: 'capitalize' },
  urgentBanner: { flexDirection: 'row', alignItems: 'center', gap: 12, marginHorizontal: spacing.lg, marginBottom: spacing.base, backgroundColor: '#FF5C3518', borderWidth: 1, borderColor: '#FF5C3550', borderRadius: radius.xl, padding: spacing.base },
  urgentTitle: { fontSize: 12, color: colors.urgent, fontWeight: '800', letterSpacing: 0.5 },
  urgentSub: { fontSize: 11, color: '#FF5C3590', marginTop: 3 },
  urgentIcon: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#FF5C3520', alignItems: 'center', justifyContent: 'center' },
  section: { padding: spacing.lg },
  heading: { fontSize: 22, color: colors.text, fontWeight: '800', marginBottom: 6 },
  subheading: { fontSize: 13, color: colors.muted, marginBottom: spacing.xl },
  formGroup: { marginBottom: spacing.lg },
  formLabel: { fontSize: 11, color: colors.muted, letterSpacing: 1, textTransform: 'uppercase', fontWeight: '700', marginBottom: 10 },
  formError: { fontSize: 11, color: colors.urgent, marginTop: 4 },
  optionRow: { flexDirection: 'row', gap: 8 },
  optionChip: { flex: 1, padding: 10, borderRadius: 14, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, alignItems: 'center' },
  optionChipActive: { backgroundColor: colors.accentDim, borderColor: colors.accent },
  optionText: { fontSize: 11, color: colors.textDim, fontWeight: '500' },
  optionTextActive: { color: colors.accent, fontWeight: '700' },
  scrollRow: { gap: 8, paddingRight: spacing.base },
  yearChip: { paddingHorizontal: 16, paddingVertical: 12, borderRadius: 14, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border },
  yearChipActive: { backgroundColor: colors.cardAlt, borderColor: colors.accent },
  yearText: { fontSize: 13, color: colors.textDim, fontWeight: '500' },
  yearTextActive: { color: colors.accent, fontWeight: '700' },
  priceRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: 16, paddingHorizontal: spacing.base, gap: 10 },
  rupee: { fontSize: 20, color: colors.muted },
  priceInput: { flex: 1, fontSize: 28, color: colors.text, fontWeight: '800', paddingVertical: 10 },
  stepper: { gap: 6 },
  stepBtn: { backgroundColor: colors.cardAlt, borderWidth: 1, borderColor: colors.border, borderRadius: 8, width: 28, height: 24, alignItems: 'center', justifyContent: 'center' },
  stepText: { color: colors.text, fontSize: 14, fontWeight: '600' },
  quickChip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 10, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border },
  quickChipActive: { backgroundColor: colors.accentDim, borderColor: colors.accent },
  quickChipText: { fontSize: 12, color: colors.muted, fontWeight: '500' },
  quickChipTextActive: { color: colors.accent, fontWeight: '700' },
  expiryChip: { flex: 1, padding: 12, borderRadius: 14, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, alignItems: 'center' },
  expiryChipActive: { backgroundColor: colors.cardAlt, borderColor: colors.accent },
  expiryUrgentActive: { backgroundColor: '#FF5C3520', borderColor: colors.urgent },
  expiryText: { fontSize: 14, color: colors.textDim, fontWeight: '700' },
  expirySub: { fontSize: 8, color: colors.urgent, marginTop: 2, fontWeight: '700' },
  descInput: { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: 16, padding: spacing.base, color: colors.text, fontSize: 14, lineHeight: 22, textAlignVertical: 'top', minHeight: 80 },
  pointsCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: radius.xl, padding: spacing.base, marginBottom: spacing.lg },
  pointsLabel: { fontSize: 12, color: colors.muted },
  pointsValue: { fontSize: 22, color: colors.accent, fontWeight: '800' },
  bonusBadge: { backgroundColor: colors.urgentBg, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
  bonusText: { fontSize: 10, color: colors.urgent, fontWeight: '700' },
  submitWrap: { padding: spacing.lg, paddingBottom: 40 },
  submitBtn: { paddingVertical: 18, alignItems: 'center', borderRadius: 20 },
  submitText: { fontSize: 16, color: colors.bg, fontWeight: '800', letterSpacing: -0.2 },
});
