// src/screens/HomeScreen.js
import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Animated, Dimensions, StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Circle, Line, Defs, LinearGradient as SvgGrad, Stop } from 'react-native-svg';
import { useSelector } from 'react-redux';
import { selectUser, selectActivity } from '../store/userSlice';
import { useAuth } from '../hooks/useAuth';
import { useListings } from '../hooks/useListings';
import { colors, spacing, radius, typography, shadows } from '../utils/theme';
import { QUICK_CATEGORIES } from '../utils/constants';
import { formatDate, getTierFromScore, getTierProgress } from '../utils/helpers';
import { fetchUserActivity } from '../store/userSlice';
import { useDispatch } from 'react-redux';

const { width } = Dimensions.get('window');
const RING_SIZE = 200;
const RING_R = 80;
const CIRCUMFERENCE = 2 * Math.PI * RING_R;

export default function HomeScreen({ navigation }) {
  const dispatch = useDispatch();
  const { uid } = useAuth();
  const profile = useSelector(selectUser);
  const activity = useSelector(selectActivity);
  const { noBuyerItems } = useListings(uid);

  const scoreAnim = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const [displayScore, setDisplayScore] = useState(0);

  const score = profile?.regenScore || 0;
  const tier = getTierFromScore(score);

  useEffect(() => {
    if (uid) dispatch(fetchUserActivity(uid));
  }, [uid]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(scoreAnim, { toValue: score, duration: 1800, useNativeDriver: false }),
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
    ]).start();

    scoreAnim.addListener(({ value }) => setDisplayScore(Math.round(value)));
    return () => scoreAnim.removeAllListeners();
  }, [score]);

  const strokeDashoffset = CIRCUMFERENCE - (score / 1000) * CIRCUMFERENCE;

  const impactCards = [
    { label: 'Items\nDiverted', value: profile?.itemsDiverted || 0, unit: 'items', icon: '♻', color: colors.accent },
    { label: 'CO₂\nSaved', value: profile?.co2Saved?.toFixed(1) || '0.0', unit: 'tonnes', icon: '🌱', color: colors.blue },
    { label: 'Meals\nRescued', value: profile?.mealsRescued || 0, unit: 'meals', icon: '🍱', color: colors.gold },
  ];

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* ── Header ── */}
        <LinearGradient colors={[colors.card, colors.bg]} style={styles.headerGrad}>
          <View style={styles.headerRow}>
            <View>
              <Text style={styles.greeting}>Welcome back</Text>
              <Text style={styles.name}>{profile?.name?.split(' ')[0] || 'Explorer'}</Text>
              <View style={styles.badgeRow}>
                <View style={[styles.badge, { backgroundColor: colors.accentDim, borderColor: '#7FEA5A30' }]}>
                  <Text style={[styles.badgeText, { color: colors.accent }]}>● {tier.icon} {tier.name}</Text>
                </View>
                <View style={[styles.badge, { backgroundColor: colors.goldBg, borderColor: '#F5C84230' }]}>
                  <Text style={[styles.badgeText, { color: colors.gold }]}>🏆 Top 5%</Text>
                </View>
              </View>
            </View>
            <TouchableOpacity onPress={() => navigation.navigate('ProfileTabs')} style={styles.avatarBtn}>
              <LinearGradient colors={[`${colors.accent}40`, `${colors.blue}40`]} style={styles.avatar}>
                <Text style={{ fontSize: 22 }}>🌿</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>

          {/* ── Score Ring ── */}
          <Animated.View style={[styles.ringWrap, { opacity: fadeAnim }]}>
            <Svg width={RING_SIZE} height={RING_SIZE} viewBox={`0 0 ${RING_SIZE} ${RING_SIZE}`}>
              <Defs>
                <SvgGrad id="g" x1="0%" y1="0%" x2="100%" y2="0%">
                  <Stop offset="0%" stopColor="#4CAF32" />
                  <Stop offset="100%" stopColor="#7FEA5A" />
                </SvgGrad>
              </Defs>
              {/* Track */}
              <Circle cx="100" cy="100" r={RING_R} fill="none" stroke={colors.border} strokeWidth="10" />
              {/* Tick marks */}
              {Array.from({ length: 40 }).map((_, i) => {
                const angle = (i / 40) * 2 * Math.PI - Math.PI / 2;
                return (
                  <Line key={i}
                    x1={100 + 88 * Math.cos(angle)} y1={100 + 88 * Math.sin(angle)}
                    x2={100 + 92 * Math.cos(angle)} y2={100 + 92 * Math.sin(angle)}
                    stroke={colors.border} strokeWidth="1"
                  />
                );
              })}
              {/* Progress */}
              <Circle cx="100" cy="100" r={RING_R}
                fill="none" stroke="url(#g)" strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={CIRCUMFERENCE}
                strokeDashoffset={strokeDashoffset}
                rotation="-90" origin="100, 100"
              />
            </Svg>
            <View style={styles.ringCenter}>
              <Text style={styles.ringLabel}>Regen Score</Text>
              <Text style={styles.ringScore}>{displayScore}</Text>
              <Text style={styles.ringMax}>/1000</Text>
              <View style={[styles.badge, { backgroundColor: colors.accentDim, borderColor: '#7FEA5A30', marginTop: 6 }]}>
                <Text style={[styles.badgeText, { color: colors.accent }]}>↑ +47 this week</Text>
              </View>
            </View>
          </Animated.View>

          {/* Tier track */}
          <View style={styles.tierRow}>
            {['Seedling', 'Grower', 'Pioneer', 'Guardian'].map((t, i) => {
              const currentIdx = ['Seedling', 'Grower', 'Pioneer', 'Guardian', 'Champion'].indexOf(tier.name);
              return (
                <View key={t} style={styles.tierItem}>
                  <View style={[styles.tierBar, { backgroundColor: i <= currentIdx ? colors.accent : colors.border, opacity: i === currentIdx ? 1 : i < currentIdx ? 0.6 : 0.3 }]} />
                  <Text style={[styles.tierText, { color: i === currentIdx ? colors.accent : colors.muted }]}>{t}</Text>
                </View>
              );
            })}
          </View>
        </LinearGradient>

        {/* ── No-Buyer Alert ── */}
        {noBuyerItems.length > 0 && (
          <TouchableOpacity
            style={styles.noBuyerAlert}
            onPress={() => navigation.navigate('NoBuyer', { listingId: noBuyerItems[0].id })}
            activeOpacity={0.85}
          >
            <Text style={{ fontSize: 22 }}>⌛</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.alertTitle}>{noBuyerItems.length} item{noBuyerItems.length > 1 ? 's' : ''} without a buyer</Text>
              <Text style={styles.alertSub}>Tap to prevent waste → earn points</Text>
            </View>
            <Text style={{ color: colors.gold, fontWeight: '700' }}>Act →</Text>
          </TouchableOpacity>
        )}

        {/* ── Impact Metrics ── */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>YOUR IMPACT</Text>
            <Text style={styles.sectionLink}>All time →</Text>
          </View>
          <View style={styles.metricsRow}>
            {impactCards.map((m, i) => (
              <Animated.View
                key={m.label}
                style={[styles.metricCard, { opacity: fadeAnim }]}
              >
                <Text style={styles.metricIcon}>{m.icon}</Text>
                <Text style={[styles.metricValue, { color: m.color }]}>{m.value}</Text>
                <Text style={styles.metricUnit}>{m.unit}</Text>
                <Text style={styles.metricLabel}>{m.label}</Text>
              </Animated.View>
            ))}
          </View>
        </View>

        {/* ── Quick List ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>QUICK LIST</Text>
          <View style={styles.quickRow}>
            {QUICK_CATEGORIES.map((q) => (
              <TouchableOpacity
                key={q.id}
                style={styles.quickCard}
                onPress={() => navigation.navigate('ScanTabs', { screen: 'Camera', params: { category: q.id } })}
                activeOpacity={0.75}
              >
                <Text style={styles.quickIcon}>{q.icon}</Text>
                <Text style={styles.quickLabel}>{q.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* ── Activity Feed ── */}
        <View style={[styles.section, { paddingBottom: 100 }]}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>RECENT ACTIVITY</Text>
            <TouchableOpacity onPress={() => navigation.navigate('MyListings')}>
              <Text style={styles.sectionLink}>See all →</Text>
            </TouchableOpacity>
          </View>
          {activity.length === 0 ? (
            <View style={styles.emptyActivity}>
              <Text style={{ fontSize: 36 }}>🌱</Text>
              <Text style={{ color: colors.muted, marginTop: 8 }}>Start listing to build your impact</Text>
            </View>
          ) : (
            activity.map((a, i) => (
              <ActivityRow key={a.id || i} item={a} />
            ))
          )}
        </View>
      </ScrollView>

      {/* ── FAB ── */}
      <TouchableOpacity
        style={styles.fab}
        onPress={() => navigation.navigate('ScanTabs')}
        activeOpacity={0.85}
      >
        <LinearGradient colors={[colors.accentDark, colors.accent]} style={styles.fabGrad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
          <Text style={styles.fabCamIcon}>📷</Text>
          <Text style={styles.fabText}>Scan to List</Text>
        </LinearGradient>
      </TouchableOpacity>
    </View>
  );
}

function ActivityRow({ item }) {
  const iconMap = { listing_created: '🔄', donation: '💙', relist: '🏷', recycling: '♻', sale: '✅' };
  const colorMap = { listing_created: colors.accent, donation: colors.blue, relist: colors.gold, recycling: colors.accent, sale: colors.accent };
  const icon = iconMap[item.action] || '⚡';
  const color = colorMap[item.action] || colors.accent;

  return (
    <View style={styles.activityRow}>
      <View style={styles.activityIcon}>
        <Text style={{ fontSize: 18 }}>{icon}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.activityTitle}>{item.category || 'Item'}</Text>
        <Text style={styles.activitySub}>{item.action?.replace('_', ' ')} • {formatDate(item.createdAt)}</Text>
      </View>
      <Text style={[styles.activityPts, { color }]}>+{item.points} pts</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  scroll: { flex: 1 },
  headerGrad: { paddingBottom: spacing.xl },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', padding: spacing.xl, paddingTop: 52 },
  greeting: { fontSize: 12, color: colors.muted, letterSpacing: 1.2, textTransform: 'uppercase', marginBottom: 3 },
  name: { fontSize: 26, color: colors.text, fontWeight: '800', letterSpacing: -0.5 },
  badgeRow: { flexDirection: 'row', gap: 6, marginTop: 8 },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: radius.full, borderWidth: 1 },
  badgeText: { fontSize: 11, fontWeight: '600' },
  avatarBtn: { marginTop: 6 },
  avatar: { width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: colors.border },
  ringWrap: { alignItems: 'center', marginTop: 8, position: 'relative' },
  ringCenter: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' },
  ringLabel: { fontSize: 11, color: colors.muted, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 2 },
  ringScore: { fontSize: 52, color: colors.text, fontWeight: '800', lineHeight: 58 },
  ringMax: { fontSize: 12, color: colors.muted },
  tierRow: { flexDirection: 'row', justifyContent: 'center', gap: 8, marginTop: 12, paddingHorizontal: spacing.xl },
  tierItem: { alignItems: 'center', gap: 3, flex: 1 },
  tierBar: { width: '100%', height: 4, borderRadius: 2 },
  tierText: { fontSize: 9, fontWeight: '600' },
  noBuyerAlert: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    margin: spacing.lg, backgroundColor: colors.goldBg,
    borderWidth: 1, borderColor: '#F5C84230', borderRadius: radius.xl,
    padding: spacing.base,
  },
  alertTitle: { fontSize: 14, color: colors.gold, fontWeight: '700' },
  alertSub: { fontSize: 12, color: colors.muted, marginTop: 2 },
  section: { paddingHorizontal: spacing.lg, paddingTop: spacing.lg },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  sectionTitle: { fontSize: 11, color: colors.muted, letterSpacing: 1.2, fontWeight: '700', textTransform: 'uppercase' },
  sectionLink: { fontSize: 12, color: colors.accent },
  metricsRow: { flexDirection: 'row', gap: 10 },
  metricCard: { flex: 1, backgroundColor: colors.card, borderRadius: radius.xl, borderWidth: 1, borderColor: colors.border, padding: 14 },
  metricIcon: { fontSize: 22, marginBottom: 8 },
  metricValue: { fontSize: 22, fontWeight: '800', lineHeight: 26 },
  metricUnit: { fontSize: 10, color: colors.muted, marginTop: 2 },
  metricLabel: { fontSize: 10, color: colors.textDim, marginTop: 4, lineHeight: 14 },
  quickRow: { flexDirection: 'row', gap: 10, marginTop: 12 },
  quickCard: { flex: 1, backgroundColor: colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: 12, alignItems: 'center', gap: 6 },
  quickIcon: { fontSize: 24 },
  quickLabel: { fontSize: 9, color: colors.textDim, textAlign: 'center', lineHeight: 12 },
  activityRow: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: colors.card, borderRadius: radius.xl, borderWidth: 1, borderColor: colors.border, padding: 14, marginBottom: 10 },
  activityIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: colors.cardAlt, alignItems: 'center', justifyContent: 'center' },
  activityTitle: { fontSize: 14, fontWeight: '600', color: colors.text, marginBottom: 3 },
  activitySub: { fontSize: 11, color: colors.muted },
  activityPts: { fontSize: 13, fontWeight: '700' },
  emptyActivity: { alignItems: 'center', padding: spacing.xxl },
  fab: { position: 'absolute', bottom: 90, alignSelf: 'center', borderRadius: 28, ...shadows.accent },
  fabGrad: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 28, paddingVertical: 16, borderRadius: 28 },
  fabCamIcon: { fontSize: 20 },
  fabText: { fontSize: 16, color: '#0D1A0F', fontWeight: '800', letterSpacing: -0.3 },
});
