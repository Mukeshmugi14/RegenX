// src/screens/MyListingsScreen.js
import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { useSelector } from 'react-redux';
import { selectMyListings } from '../store/listingsSlice';
import { colors, spacing, radius } from '../utils/theme';
import { formatDate, formatPrice } from '../utils/helpers';
import { LISTING_STATUS } from '../utils/constants';

const STATUS_CONFIG = {
  [LISTING_STATUS.ACTIVE]: { label: 'Active', color: colors.accent, bg: colors.accentDim },
  [LISTING_STATUS.SOLD]: { label: 'Sold', color: colors.blue, bg: colors.blueBg },
  [LISTING_STATUS.DONATED]: { label: 'Donated', color: colors.blue, bg: colors.blueBg },
  [LISTING_STATUS.RECYCLED]: { label: 'Recycled', color: colors.accent, bg: colors.accentDim },
  [LISTING_STATUS.EXPIRED]: { label: 'Expired', color: colors.muted, bg: colors.card },
  [LISTING_STATUS.NO_BUYER]: { label: 'No Buyer', color: colors.urgent, bg: colors.urgentBg },
};

const FILTERS = ['All', 'Active', 'Sold', 'Donated', 'Recycled'];

export default function MyListingsScreen({ navigation }) {
  const listings = useSelector(selectMyListings);
  const [filter, setFilter] = useState('All');

  const filtered = filter === 'All' ? listings : listings.filter((l) => l.status?.toLowerCase() === filter.toLowerCase());

  return (
    <View style={styles.root}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.title}>My Listings</Text>
        <Text style={styles.count}>{listings.length}</Text>
      </View>

      {/* Filter tabs */}
      <View style={styles.filterRow}>
        {FILTERS.map((f) => (
          <TouchableOpacity key={f} onPress={() => setFilter(f)} style={[styles.filterChip, filter === f && styles.filterChipActive]} activeOpacity={0.7}>
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>{f}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={{ fontSize: 36, marginBottom: 10 }}>📦</Text>
            <Text style={{ color: colors.muted, textAlign: 'center' }}>No {filter.toLowerCase()} listings yet</Text>
          </View>
        }
        renderItem={({ item }) => {
          const status = STATUS_CONFIG[item.status] || STATUS_CONFIG.active;
          return (
            <TouchableOpacity
              style={styles.card}
              onPress={() => item.status === LISTING_STATUS.NO_BUYER && navigation.navigate('NoBuyer', { listingId: item.id })}
              activeOpacity={0.8}
            >
              <View style={styles.cardLeft}>
                <Text style={{ fontSize: 28 }}>{item.category === 'food' ? '🥗' : item.category === 'crop_residue' ? '🌾' : item.category === 'ewaste' ? '🔌' : '📦'}</Text>
              </View>
              <View style={{ flex: 1, gap: 4 }}>
                <Text style={styles.cardTitle}>{item.itemName || 'Item'}</Text>
                <Text style={styles.cardMeta}>{item.condition} · {item.year} · {formatDate(item.listedAt)}</Text>
                <View style={styles.cardBottom}>
                  <Text style={styles.cardPrice}>{formatPrice(item.price)}</Text>
                  <View style={[styles.statusBadge, { backgroundColor: status.bg }]}>
                    <Text style={[styles.statusText, { color: status.color }]}>{status.label}</Text>
                  </View>
                </View>
              </View>
              {item.status === LISTING_STATUS.NO_BUYER && (
                <View style={styles.noBuyerArrow}><Text style={{ color: colors.urgent, fontSize: 16 }}>!</Text></View>
              )}
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: spacing.xl, paddingTop: 56 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
  backText: { color: colors.text, fontSize: 18 },
  title: { flex: 1, fontSize: 20, color: colors.text, fontWeight: '800' },
  count: { fontSize: 14, color: colors.muted, backgroundColor: colors.card, borderRadius: radius.full, paddingHorizontal: 10, paddingVertical: 4, borderWidth: 1, borderColor: colors.border },
  filterRow: { flexDirection: 'row', gap: 8, paddingHorizontal: spacing.lg, paddingBottom: spacing.base },
  filterChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: radius.full, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border },
  filterChipActive: { backgroundColor: colors.accentDim, borderColor: colors.accent },
  filterText: { fontSize: 12, color: colors.muted, fontWeight: '500' },
  filterTextActive: { color: colors.accent, fontWeight: '700' },
  list: { paddingHorizontal: spacing.lg, paddingBottom: 100, gap: 10 },
  card: { flexDirection: 'row', gap: 14, backgroundColor: colors.card, borderRadius: radius.xl, borderWidth: 1, borderColor: colors.border, padding: spacing.base, alignItems: 'center' },
  cardLeft: { width: 48, height: 48, borderRadius: 14, backgroundColor: colors.cardAlt, alignItems: 'center', justifyContent: 'center' },
  cardTitle: { fontSize: 14, color: colors.text, fontWeight: '600' },
  cardMeta: { fontSize: 11, color: colors.muted },
  cardBottom: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  cardPrice: { fontSize: 13, color: colors.accent, fontWeight: '700' },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.full },
  statusText: { fontSize: 10, fontWeight: '700' },
  noBuyerArrow: { width: 28, height: 28, borderRadius: 14, backgroundColor: colors.urgentBg, borderWidth: 1, borderColor: '#FF5C3530', alignItems: 'center', justifyContent: 'center' },
  empty: { alignItems: 'center', paddingTop: 80 },
});
