// src/screens/ProfileScreen.js
import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useDispatch, useSelector } from 'react-redux';
import { selectUser, clearUser } from '../store/userSlice';
import { logoutUser } from '../firebase/auth';
import { colors, spacing, radius } from '../utils/theme';
import { getTierFromScore } from '../utils/helpers';
import { TIERS } from '../utils/constants';

export default function ProfileScreen() {
  const dispatch = useDispatch();
  const profile = useSelector(selectUser);
  const tier = getTierFromScore(profile?.regenScore || 0);

  const handleLogout = () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign Out', style: 'destructive', onPress: async () => { await logoutUser(); dispatch(clearUser()); } },
    ]);
  };

  const stats = [
    { label: 'Regen Score', value: profile?.regenScore || 0, icon: '⭐', color: colors.accent },
    { label: 'Items Diverted', value: profile?.itemsDiverted || 0, icon: '♻', color: colors.accent },
    { label: 'CO₂ Saved (kg)', value: ((profile?.co2Saved || 0) * 1000).toFixed(0), icon: '🌱', color: colors.blue },
    { label: 'Meals Rescued', value: profile?.mealsRescued || 0, icon: '🍱', color: colors.gold },
  ];

  return (
    <ScrollView style={styles.root} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <LinearGradient colors={[colors.card, colors.bg]} style={styles.header}>
        <View style={styles.avatar}>
          <Text style={{ fontSize: 32 }}>🌿</Text>
        </View>
        <Text style={styles.name}>{profile?.name || 'Explorer'}</Text>
        <Text style={styles.email}>{profile?.email}</Text>
        <View style={styles.tierBadge}>
          <Text style={styles.tierBadgeText}>{tier.icon} {tier.name} — {profile?.regenScore || 0}/1000</Text>
        </View>
        <Text style={styles.roleLabel}>{profile?.role?.toUpperCase() || 'USER'}</Text>
      </LinearGradient>

      {/* Stats */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>MY IMPACT</Text>
        <View style={styles.statsGrid}>
          {stats.map((s) => (
            <View key={s.label} style={styles.statCard}>
              <Text style={{ fontSize: 22, marginBottom: 6 }}>{s.icon}</Text>
              <Text style={[styles.statVal, { color: s.color }]}>{s.value}</Text>
              <Text style={styles.statLabel}>{s.label}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Tier Journey */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>TIER JOURNEY</Text>
        {TIERS.map((t, i) => {
          const unlocked = (profile?.regenScore || 0) >= t.min;
          const isCurrent = tier.name === t.name;
          return (
            <View key={t.name} style={[styles.tierRow, isCurrent && styles.tierRowActive]}>
              <Text style={styles.tierIcon}>{t.icon}</Text>
              <View style={{ flex: 1 }}>
                <Text style={[styles.tierName, unlocked ? { color: colors.text } : { color: colors.muted }]}>{t.name}</Text>
                <Text style={styles.tierRange}>{t.min} – {t.max === 1000 ? '1000' : t.max} pts</Text>
              </View>
              {isCurrent && <View style={styles.currentBadge}><Text style={styles.currentBadgeText}>Current</Text></View>}
              {unlocked && !isCurrent && <Text style={{ color: colors.accent, fontSize: 16 }}>✓</Text>}
            </View>
          );
        })}
      </View>

      {/* Settings */}
      <View style={[styles.section, { paddingBottom: 100 }]}>
        <Text style={styles.sectionTitle}>SETTINGS</Text>
        {[
          { label: 'Edit Profile', icon: '✏️' },
          { label: 'Notification Preferences', icon: '🔔' },
          { label: 'My Donations', icon: '💙' },
          { label: 'Transaction History', icon: '📋' },
          { label: 'Help & Support', icon: '❓' },
        ].map((item) => (
          <TouchableOpacity key={item.label} style={styles.settingRow} activeOpacity={0.7}>
            <Text style={{ fontSize: 20 }}>{item.icon}</Text>
            <Text style={styles.settingLabel}>{item.label}</Text>
            <Text style={{ color: colors.muted, fontSize: 16 }}>›</Text>
          </TouchableOpacity>
        ))}

        <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn} activeOpacity={0.7}>
          <Text style={styles.logoutText}>Sign Out</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { alignItems: 'center', paddingTop: 60, paddingBottom: 28, paddingHorizontal: spacing.xl },
  avatar: { width: 80, height: 80, borderRadius: 40, backgroundColor: colors.cardAlt, borderWidth: 3, borderColor: colors.border, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  name: { fontSize: 24, color: colors.text, fontWeight: '800', marginBottom: 3 },
  email: { fontSize: 13, color: colors.muted, marginBottom: 10 },
  tierBadge: { backgroundColor: colors.accentDim, borderRadius: radius.full, paddingHorizontal: 14, paddingVertical: 6, borderWidth: 1, borderColor: '#7FEA5A30', marginBottom: 6 },
  tierBadgeText: { fontSize: 13, color: colors.accent, fontWeight: '700' },
  roleLabel: { fontSize: 10, color: colors.muted, letterSpacing: 1.5 },
  section: { padding: spacing.lg, paddingTop: spacing.xl },
  sectionTitle: { fontSize: 11, color: colors.muted, letterSpacing: 1.2, fontWeight: '700', textTransform: 'uppercase', marginBottom: 14 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  statCard: { width: '47%', backgroundColor: colors.card, borderRadius: radius.xl, borderWidth: 1, borderColor: colors.border, padding: 14 },
  statVal: { fontSize: 24, fontWeight: '800', lineHeight: 28, marginBottom: 3 },
  statLabel: { fontSize: 11, color: colors.muted },
  tierRow: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.base, marginBottom: 8 },
  tierRowActive: { borderColor: colors.accent, backgroundColor: colors.accentDim },
  tierIcon: { fontSize: 22 },
  tierName: { fontSize: 14, fontWeight: '700' },
  tierRange: { fontSize: 11, color: colors.muted, marginTop: 1 },
  currentBadge: { backgroundColor: colors.accentDim, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 },
  currentBadgeText: { fontSize: 10, color: colors.accent, fontWeight: '700' },
  settingRow: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.base, marginBottom: 8 },
  settingLabel: { flex: 1, fontSize: 14, color: colors.text, fontWeight: '500' },
  logoutBtn: { backgroundColor: colors.urgentBg, borderWidth: 1, borderColor: '#FF5C3530', borderRadius: radius.lg, padding: spacing.base, alignItems: 'center', marginTop: spacing.base },
  logoutText: { fontSize: 15, color: colors.urgent, fontWeight: '700' },
});
