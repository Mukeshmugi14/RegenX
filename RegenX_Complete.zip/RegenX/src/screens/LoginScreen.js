// src/screens/LoginScreen.js
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, Alert, ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { loginUser } from '../firebase/auth';
import { useDispatch } from 'react-redux';
import { setFirebaseUser } from '../store/userSlice';
import { colors, spacing, radius, shadows } from '../utils/theme';

export default function LoginScreen({ navigation }) {
  const dispatch = useDispatch();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Missing Fields', 'Please enter your email and password.');
      return;
    }
    setLoading(true);
    try {
      const user = await loginUser(email.trim(), password);
      dispatch(setFirebaseUser({ uid: user.uid, email: user.email, displayName: user.displayName }));
    } catch (err) {
      let msg = 'Login failed. Please try again.';
      if (err.code === 'auth/user-not-found') msg = 'No account found with this email.';
      if (err.code === 'auth/wrong-password') msg = 'Incorrect password.';
      if (err.code === 'auth/too-many-requests') msg = 'Too many attempts. Please try again later.';
      Alert.alert('Login Failed', msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <LinearGradient colors={[colors.bgDeep, colors.bg]} style={styles.bg}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          {/* Logo */}
          <View style={styles.logo}>
            <Text style={{ fontSize: 48 }}>♻</Text>
            <Text style={styles.logoText}>RegenX</Text>
            <Text style={styles.tagline}>Circular Economy Platform</Text>
          </View>

          {/* Form */}
          <View style={styles.form}>
            <Text style={styles.formTitle}>Welcome Back</Text>

            <View style={styles.inputWrap}>
              <Text style={styles.inputLabel}>Email</Text>
              <TextInput
                style={styles.input}
                value={email}
                onChangeText={setEmail}
                placeholder="you@example.com"
                placeholderTextColor={colors.muted}
                keyboardType="email-address"
                autoCapitalize="none"
                selectionColor={colors.accent}
              />
            </View>

            <View style={styles.inputWrap}>
              <Text style={styles.inputLabel}>Password</Text>
              <TextInput
                style={styles.input}
                value={password}
                onChangeText={setPassword}
                placeholder="••••••••"
                placeholderTextColor={colors.muted}
                secureTextEntry
                selectionColor={colors.accent}
              />
            </View>

            <TouchableOpacity onPress={handleLogin} disabled={loading} activeOpacity={0.85} style={{ borderRadius: radius.xl, overflow: 'hidden', ...shadows.accent }}>
              <LinearGradient colors={[colors.accentDark, colors.accent]} style={styles.loginBtn}>
                <Text style={styles.loginBtnText}>{loading ? '⏳ Signing in...' : '🌱 Sign In'}</Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => navigation.navigate('Register')} style={styles.registerLink} activeOpacity={0.7}>
              <Text style={styles.registerText}>Don't have an account? <Text style={{ color: colors.accent, fontWeight: '700' }}>Create one →</Text></Text>
            </TouchableOpacity>
          </View>

          {/* Role pills */}
          <View style={styles.roles}>
            <Text style={styles.rolesLabel}>Built for</Text>
            <View style={styles.rolesRow}>
              {['🌾 Farmers', '🏪 Consumers', '👥 SHGs', '🚛 Transporters'].map((r) => (
                <View key={r} style={styles.rolePill}>
                  <Text style={styles.rolePillText}>{r}</Text>
                </View>
              ))}
            </View>
          </View>
        </ScrollView>
      </LinearGradient>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  bg: { flex: 1 },
  content: { flexGrow: 1, padding: spacing.xl, justifyContent: 'center', paddingTop: 80 },
  logo: { alignItems: 'center', marginBottom: 48 },
  logoText: { fontSize: 36, color: colors.accent, fontWeight: '800', letterSpacing: -1, marginTop: 8 },
  tagline: { fontSize: 13, color: colors.muted, marginTop: 4 },
  form: { backgroundColor: colors.card, borderRadius: 28, padding: spacing.xl, borderWidth: 1, borderColor: colors.border, marginBottom: spacing.xl },
  formTitle: { fontSize: 22, color: colors.text, fontWeight: '800', marginBottom: spacing.xl },
  inputWrap: { marginBottom: spacing.base },
  inputLabel: { fontSize: 11, color: colors.muted, letterSpacing: 1, textTransform: 'uppercase', fontWeight: '700', marginBottom: 6 },
  input: { backgroundColor: colors.cardAlt, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.base, color: colors.text, fontSize: 15 },
  loginBtn: { paddingVertical: 16, alignItems: 'center', borderRadius: radius.xl },
  loginBtnText: { fontSize: 16, color: colors.bg, fontWeight: '800' },
  registerLink: { alignItems: 'center', marginTop: spacing.base },
  registerText: { fontSize: 13, color: colors.muted },
  roles: { alignItems: 'center' },
  rolesLabel: { fontSize: 11, color: colors.muted, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 10 },
  rolesRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center' },
  rolePill: { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: radius.full, paddingHorizontal: 12, paddingVertical: 6 },
  rolePillText: { fontSize: 12, color: colors.textDim },
});
