// src/store/listingsSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import {
  createListing,
  getUserListings,
  getNoBuyerListings,
  updateListingStatus,
  relistAtLowerPrice,
  donateToNGO,
} from '../firebase/firestore';

export const submitListing = createAsyncThunk(
  'listings/submit',
  async ({ uid, data }, { rejectWithValue }) => {
    try {
      const id = await createListing(uid, data);
      return { id, ...data };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const fetchMyListings = createAsyncThunk(
  'listings/fetchMine',
  async (uid, { rejectWithValue }) => {
    try {
      return await getUserListings(uid);
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const fetchNoBuyerListings = createAsyncThunk(
  'listings/fetchNoBuyer',
  async (uid, { rejectWithValue }) => {
    try {
      return await getNoBuyerListings(uid);
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const relistItem = createAsyncThunk(
  'listings/relist',
  async ({ listingId, newPrice, uid }, { rejectWithValue }) => {
    try {
      await relistAtLowerPrice(listingId, newPrice, uid);
      return { listingId, newPrice };
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const donateItem = createAsyncThunk(
  'listings/donate',
  async ({ listingId, ngoId, uid }, { rejectWithValue }) => {
    try {
      await donateToNGO(listingId, ngoId, uid);
      return listingId;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

const listingsSlice = createSlice({
  name: 'listings',
  initialState: {
    myListings: [],
    noBuyerItems: [],
    draftListing: {
      imageUri: null,
      imageUrl: null,
      category: null,
      aiDetected: null,
      condition: 'Good',
      year: '2023',
      price: '250',
      expiryDays: null,
      description: '',
    },
    submitting: false,
    loading: false,
    error: null,
    lastSubmittedId: null,
  },
  reducers: {
    updateDraft(state, action) {
      state.draftListing = { ...state.draftListing, ...action.payload };
    },
    clearDraft(state) {
      state.draftListing = {
        imageUri: null,
        imageUrl: null,
        category: null,
        aiDetected: null,
        condition: 'Good',
        year: '2023',
        price: '250',
        expiryDays: null,
        description: '',
      };
    },
    setListings(state, action) {
      state.myListings = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(submitListing.pending, (state) => { state.submitting = true; })
      .addCase(submitListing.fulfilled, (state, action) => {
        state.submitting = false;
        state.myListings.unshift(action.payload);
        state.lastSubmittedId = action.payload.id;
      })
      .addCase(submitListing.rejected, (state, action) => {
        state.submitting = false;
        state.error = action.payload;
      })
      .addCase(fetchMyListings.fulfilled, (state, action) => {
        state.myListings = action.payload;
        state.loading = false;
      })
      .addCase(fetchNoBuyerListings.fulfilled, (state, action) => {
        state.noBuyerItems = action.payload;
      })
      .addCase(relistItem.fulfilled, (state, action) => {
        const idx = state.noBuyerItems.findIndex((l) => l.id === action.payload.listingId);
        if (idx !== -1) state.noBuyerItems.splice(idx, 1);
      })
      .addCase(donateItem.fulfilled, (state, action) => {
        const idx = state.noBuyerItems.findIndex((l) => l.id === action.payload);
        if (idx !== -1) state.noBuyerItems.splice(idx, 1);
      });
  },
});

export const { updateDraft, clearDraft, setListings } = listingsSlice.actions;

export const selectMyListings = (state) => state.listings.myListings;
export const selectNoBuyerItems = (state) => state.listings.noBuyerItems;
export const selectDraftListing = (state) => state.listings.draftListing;
export const selectSubmitting = (state) => state.listings.submitting;

export default listingsSlice.reducer;
