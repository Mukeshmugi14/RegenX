// src/store/userSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { getUserProfile, getUserActivity, updateUserScore } from '../firebase/firestore';

// ─── Async thunks ──────────────────────────────────────────────────
export const fetchUserProfile = createAsyncThunk(
  'user/fetchProfile',
  async (uid, { rejectWithValue }) => {
    try {
      return await getUserProfile(uid);
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const fetchUserActivity = createAsyncThunk(
  'user/fetchActivity',
  async (uid, { rejectWithValue }) => {
    try {
      return await getUserActivity(uid, 10);
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const awardPoints = createAsyncThunk(
  'user/awardPoints',
  async ({ uid, points, action, category }, { rejectWithValue }) => {
    try {
      return await updateUserScore(uid, points, action, category);
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

// ─── Slice ─────────────────────────────────────────────────────────
const userSlice = createSlice({
  name: 'user',
  initialState: {
    firebaseUser: null,
    profile: null,
    activity: [],
    loading: false,
    error: null,
    profileLoaded: false,
  },
  reducers: {
    setFirebaseUser(state, action) {
      state.firebaseUser = action.payload;
    },
    setProfile(state, action) {
      state.profile = action.payload;
      state.profileLoaded = true;
    },
    updateScoreLocally(state, action) {
      if (state.profile) {
        state.profile.regenScore = Math.min(1000, state.profile.regenScore + action.payload);
      }
    },
    clearUser(state) {
      state.firebaseUser = null;
      state.profile = null;
      state.activity = [];
      state.profileLoaded = false;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchUserProfile.pending, (state) => { state.loading = true; })
      .addCase(fetchUserProfile.fulfilled, (state, action) => {
        state.profile = action.payload;
        state.loading = false;
        state.profileLoaded = true;
      })
      .addCase(fetchUserProfile.rejected, (state, action) => {
        state.error = action.payload;
        state.loading = false;
      })
      .addCase(fetchUserActivity.fulfilled, (state, action) => {
        state.activity = action.payload;
      })
      .addCase(awardPoints.fulfilled, (state, action) => {
        if (state.profile && action.payload) {
          state.profile.regenScore = action.payload.newScore;
          state.profile.tier = action.payload.newTier;
        }
      });
  },
});

export const { setFirebaseUser, setProfile, updateScoreLocally, clearUser } = userSlice.actions;

// ─── Selectors ─────────────────────────────────────────────────────
export const selectUser = (state) => state.user.profile;
export const selectFirebaseUser = (state) => state.user.firebaseUser;
export const selectRegenScore = (state) => state.user.profile?.regenScore ?? 0;
export const selectActivity = (state) => state.user.activity;
export const selectUserLoading = (state) => state.user.loading;

export default userSlice.reducer;
