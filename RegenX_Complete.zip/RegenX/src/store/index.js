// src/store/index.js
import { configureStore } from '@reduxjs/toolkit';
import userReducer from './userSlice';
import listingsReducer from './listingsSlice';
import uiReducer from './uiSlice';

export const store = configureStore({
  reducer: {
    user: userReducer,
    listings: listingsReducer,
    ui: uiReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        // Firebase Timestamp objects are not serializable
        ignoredActions: ['user/setProfile', 'listings/setListings', 'listings/addListing'],
        ignoredPaths: ['user.profile', 'listings.items'],
      },
    }),
});

export default store;
