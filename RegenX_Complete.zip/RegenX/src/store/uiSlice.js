// src/store/uiSlice.js
import { createSlice } from '@reduxjs/toolkit';

const uiSlice = createSlice({
  name: 'ui',
  initialState: {
    toasts: [],
    cameraActive: false,
    listingModalVisible: false,
    noBuyerModalVisible: false,
    globalLoading: false,
  },
  reducers: {
    showToast(state, action) {
      state.toasts.push({
        id: Date.now().toString(),
        message: action.payload.message,
        type: action.payload.type || 'success', // success | error | warning | info
        duration: action.payload.duration || 3000,
      });
    },
    removeToast(state, action) {
      state.toasts = state.toasts.filter((t) => t.id !== action.payload);
    },
    setCameraActive(state, action) {
      state.cameraActive = action.payload;
    },
    setGlobalLoading(state, action) {
      state.globalLoading = action.payload;
    },
  },
});

export const { showToast, removeToast, setCameraActive, setGlobalLoading } = uiSlice.actions;
export const selectToasts = (state) => state.ui.toasts;
export default uiSlice.reducer;
