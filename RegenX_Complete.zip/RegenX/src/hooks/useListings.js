// src/hooks/useListings.js
import { useEffect, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { subscribeToUserListings } from '../firebase/firestore';
import {
  fetchNoBuyerListings,
  setListings,
  selectMyListings,
  selectNoBuyerItems,
  selectSubmitting,
} from '../store/listingsSlice';

export const useListings = (uid) => {
  const dispatch = useDispatch();
  const myListings = useSelector(selectMyListings);
  const noBuyerItems = useSelector(selectNoBuyerItems);
  const submitting = useSelector(selectSubmitting);

  // Real-time listing subscription
  useEffect(() => {
    if (!uid) return;
    const unsub = subscribeToUserListings(uid, (listings) => {
      dispatch(setListings(listings));
    });
    return () => unsub();
  }, [uid, dispatch]);

  const refreshNoBuyer = useCallback(() => {
    if (uid) dispatch(fetchNoBuyerListings(uid));
  }, [uid, dispatch]);

  return { myListings, noBuyerItems, submitting, refreshNoBuyer };
};
