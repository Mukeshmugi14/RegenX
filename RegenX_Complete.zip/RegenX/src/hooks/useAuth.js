// src/hooks/useAuth.js
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { subscribeToAuthChanges } from '../firebase/auth';
import { subscribeToUserStats } from '../firebase/firestore';
import {
  setFirebaseUser,
  setProfile,
  clearUser,
  selectFirebaseUser,
  selectUser,
} from '../store/userSlice';

export const useAuth = () => {
  const dispatch = useDispatch();
  const firebaseUser = useSelector(selectFirebaseUser);
  const profile = useSelector(selectUser);

  useEffect(() => {
    // Listen to Firebase Auth state
    const unsubAuth = subscribeToAuthChanges((fbUser) => {
      dispatch(setFirebaseUser(fbUser ? { uid: fbUser.uid, email: fbUser.email, displayName: fbUser.displayName } : null));

      if (!fbUser) {
        dispatch(clearUser());
      }
    });

    return () => unsubAuth();
  }, [dispatch]);

  useEffect(() => {
    if (!firebaseUser?.uid) return;

    // Real-time Firestore listener for user stats
    const unsubProfile = subscribeToUserStats(firebaseUser.uid, (profileData) => {
      dispatch(setProfile(profileData));
    });

    return () => unsubProfile();
  }, [firebaseUser?.uid, dispatch]);

  return {
    firebaseUser,
    profile,
    isLoggedIn: !!firebaseUser,
    uid: firebaseUser?.uid,
  };
};
