// src/firebase/config.js
import { initializeApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// 🔐 Replace with your Firebase project credentials from:
// https://console.firebase.google.com → Project Settings → Your Apps → Web App
const firebaseConfig = {
  apiKey: 'YOUR_API_KEY',
  authDomain: 'regenx-app.firebaseapp.com',
  projectId: 'regenx-app',
  storageBucket: 'regenx-app.appspot.com',
  messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
  appId: 'YOUR_APP_ID',
  measurementId: 'YOUR_MEASUREMENT_ID',
};

// Initialize Firebase only once
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export default app;
