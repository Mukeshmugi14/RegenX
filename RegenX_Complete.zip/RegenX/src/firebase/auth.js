// src/firebase/auth.js
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  sendPasswordResetEmail,
  sendEmailVerification,
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './config';

// ─── Register new user ─────────────────────────────────────────────
export const registerUser = async ({ email, password, name, role, phone }) => {
  const credential = await createUserWithEmailAndPassword(auth, email, password);
  const user = credential.user;

  await updateProfile(user, { displayName: name });
  await sendEmailVerification(user);

  // Create Firestore user document
  await setDoc(doc(db, 'users', user.uid), {
    uid: user.uid,
    name,
    email,
    phone: phone || '',
    role, // 'farmer' | 'consumer' | 'shg' | 'transporter'
    regenScore: 0,
    itemsDiverted: 0,
    co2Saved: 0,
    mealsRescued: 0,
    tier: 'Seedling',
    joinedAt: serverTimestamp(),
    lastActive: serverTimestamp(),
    verified: false,
    location: null,
    profileComplete: false,
  });

  return user;
};

// ─── Sign in ──────────────────────────────────────────────────────
export const loginUser = async (email, password) => {
  const credential = await signInWithEmailAndPassword(auth, email, password);
  return credential.user;
};

// ─── Sign out ─────────────────────────────────────────────────────
export const logoutUser = async () => {
  await signOut(auth);
};

// ─── Get current user profile from Firestore ─────────────────────
export const getUserProfile = async (uid) => {
  const snap = await getDoc(doc(db, 'users', uid));
  if (snap.exists()) return { id: snap.id, ...snap.data() };
  return null;
};

// ─── Auth state listener ──────────────────────────────────────────
export const subscribeToAuthChanges = (callback) => {
  return onAuthStateChanged(auth, callback);
};

// ─── Password reset ───────────────────────────────────────────────
export const resetPassword = async (email) => {
  await sendPasswordResetEmail(auth, email);
};
