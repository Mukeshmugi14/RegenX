// src/firebase/storage.js
import { ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { storage } from './config';

// ─── Upload listing image (live camera only, no gallery) ──────────
export const uploadListingImage = async (uri, uid, onProgress) => {
  const filename = `listings/${uid}/${Date.now()}.jpg`;
  const storageRef = ref(storage, filename);

  // Convert URI to blob
  const response = await fetch(uri);
  const blob = await response.blob();

  return new Promise((resolve, reject) => {
    const uploadTask = uploadBytesResumable(storageRef, blob, {
      contentType: 'image/jpeg',
      customMetadata: {
        uploadedBy: uid,
        source: 'live_camera', // Trust enforcement metadata
        timestamp: Date.now().toString(),
      },
    });

    uploadTask.on(
      'state_changed',
      (snapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        if (onProgress) onProgress(Math.round(progress));
      },
      (error) => reject(error),
      async () => {
        const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
        resolve({ url: downloadURL, path: filename });
      }
    );
  });
};

// ─── Upload profile picture ────────────────────────────────────────
export const uploadProfilePicture = async (uri, uid) => {
  const filename = `profiles/${uid}/avatar.jpg`;
  const storageRef = ref(storage, filename);
  const response = await fetch(uri);
  const blob = await response.blob();
  await uploadBytesResumable(storageRef, blob, { contentType: 'image/jpeg' });
  return await getDownloadURL(storageRef);
};

// ─── Delete image ──────────────────────────────────────────────────
export const deleteImage = async (path) => {
  const imageRef = ref(storage, path);
  await deleteObject(imageRef);
};
