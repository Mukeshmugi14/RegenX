// src/firebase/firestore.js
import {
  collection,
  doc,
  addDoc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  serverTimestamp,
  increment,
  arrayUnion,
  Timestamp,
} from 'firebase/firestore';
import { db } from './config';

// ════════════════════════════════════════════
// LISTINGS
// ════════════════════════════════════════════

export const createListing = async (uid, listingData) => {
  const ref = await addDoc(collection(db, 'listings'), {
    ...listingData,
    sellerId: uid,
    status: 'active', // active | sold | donated | recycled | expired | no_buyer
    views: 0,
    inquiries: 0,
    listedAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    expiresAt: listingData.expiryDays
      ? Timestamp.fromDate(
          new Date(Date.now() + listingData.expiryDays * 86400000)
        )
      : null,
    noBuyerAt: Timestamp.fromDate(new Date(Date.now() + 7 * 86400000)),
    autoRouted: listingData.expiryDays <= 2 || false,
  });

  // Award regen points
  const pts = calcListingPoints(listingData);
  await updateUserScore(uid, pts, 'listing_created', listingData.category);

  return ref.id;
};

export const getUserListings = async (uid) => {
  const q = query(
    collection(db, 'listings'),
    where('sellerId', '==', uid),
    orderBy('listedAt', 'desc')
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
};

export const getActiveListings = async (category = null, limitNum = 20) => {
  let q = query(
    collection(db, 'listings'),
    where('status', '==', 'active'),
    orderBy('listedAt', 'desc'),
    limit(limitNum)
  );
  if (category) {
    q = query(
      collection(db, 'listings'),
      where('status', '==', 'active'),
      where('category', '==', category),
      orderBy('listedAt', 'desc'),
      limit(limitNum)
    );
  }
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
};

export const getNoBuyerListings = async (uid) => {
  const now = Timestamp.now();
  const q = query(
    collection(db, 'listings'),
    where('sellerId', '==', uid),
    where('status', '==', 'active'),
    where('noBuyerAt', '<=', now)
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
};

export const updateListingStatus = async (listingId, status, extra = {}) => {
  await updateDoc(doc(db, 'listings', listingId), {
    status,
    updatedAt: serverTimestamp(),
    ...extra,
  });
};

export const relistAtLowerPrice = async (listingId, newPrice, uid) => {
  await updateDoc(doc(db, 'listings', listingId), {
    price: newPrice,
    status: 'active',
    noBuyerAt: Timestamp.fromDate(new Date(Date.now() + 7 * 86400000)),
    updatedAt: serverTimestamp(),
    relistCount: increment(1),
  });
  await updateUserScore(uid, 12, 'relist', null);
};

export const donateToNGO = async (listingId, ngoId, uid) => {
  await updateDoc(doc(db, 'listings', listingId), {
    status: 'donated',
    donatedToNGO: ngoId,
    donatedAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  // Create donation record
  await addDoc(collection(db, 'donations'), {
    listingId,
    donorId: uid,
    ngoId,
    donatedAt: serverTimestamp(),
    status: 'pending_pickup',
  });

  await updateUserScore(uid, 28, 'donation', null);
};

export const subscribeToUserListings = (uid, callback) => {
  const q = query(
    collection(db, 'listings'),
    where('sellerId', '==', uid),
    orderBy('listedAt', 'desc'),
    limit(20)
  );
  return onSnapshot(q, (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
  });
};

// ════════════════════════════════════════════
// REGEN SCORE & USER STATS
// ════════════════════════════════════════════

export const updateUserScore = async (uid, points, action, category) => {
  const tierThresholds = [
    { min: 0, tier: 'Seedling' },
    { min: 250, tier: 'Grower' },
    { min: 500, tier: 'Pioneer' },
    { min: 750, tier: 'Guardian' },
    { min: 1000, tier: 'Champion' },
  ];

  const userRef = doc(db, 'users', uid);
  const snap = await getDoc(userRef);
  const current = snap.data();
  const newScore = Math.min(1000, (current.regenScore || 0) + points);
  const newTier = tierThresholds.findLast((t) => newScore >= t.min)?.tier || 'Seedling';

  const updates = {
    regenScore: newScore,
    tier: newTier,
    lastActive: serverTimestamp(),
  };

  // Category-specific stat updates
  if (category === 'Food' || action === 'donation') {
    updates.mealsRescued = increment(Math.floor(points / 2));
  }
  updates.itemsDiverted = increment(1);
  updates.co2Saved = increment(parseFloat((points * 0.004).toFixed(3)));

  await updateDoc(userRef, updates);

  // Log activity
  await addDoc(collection(db, 'users', uid, 'activity'), {
    action,
    points,
    category,
    newScore,
    tier: newTier,
    createdAt: serverTimestamp(),
  });

  return { newScore, newTier, points };
};

export const getUserStats = async (uid) => {
  const snap = await getDoc(doc(db, 'users', uid));
  return snap.exists() ? snap.data() : null;
};

export const subscribeToUserStats = (uid, callback) => {
  return onSnapshot(doc(db, 'users', uid), (snap) => {
    if (snap.exists()) callback({ id: snap.id, ...snap.data() });
  });
};

export const getUserActivity = async (uid, limitNum = 10) => {
  const q = query(
    collection(db, 'users', uid, 'activity'),
    orderBy('createdAt', 'desc'),
    limit(limitNum)
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
};

// ════════════════════════════════════════════
// NGOs
// ════════════════════════════════════════════

export const getVerifiedNGOs = async () => {
  const q = query(
    collection(db, 'ngos'),
    where('verified', '==', true),
    where('acceptingDonations', '==', true)
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
};

// ════════════════════════════════════════════
// RECYCLING CENTRES
// ════════════════════════════════════════════

export const getRecyclingCentres = async () => {
  const snap = await getDocs(collection(db, 'recyclingCentres'));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
};

// ════════════════════════════════════════════
// HELPERS
// ════════════════════════════════════════════

const calcListingPoints = ({ category, expiryDays, price, condition }) => {
  let pts = 15;
  if (category === 'Food' && expiryDays <= 2) pts += 20;
  else if (category === 'Food') pts += 8;
  if (condition === 'Like New') pts += 5;
  if (price === 0) pts += 10; // Free listings get bonus
  return pts;
};
